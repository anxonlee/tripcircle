<!--
  DRAFT — NOT YET REVIEWED BY COUNSEL.

  Written to describe what the app actually does as of the current build.
  Every factual claim below was checked against the code, but this is a
  starting point for a lawyer, not a finished policy. Before publishing:

    1. Have a lawyer review it (PRD §10 item 2).
    2. Replace every [BRACKETED] placeholder.
    3. The published copy is docs/privacy/index.html, served by GitHub Pages
       at https://anxonlee.github.io/pirt/privacy/ — the URL the app
       links to. Edit BOTH this file and that one, or they will drift.
    4. Re-check it whenever data handling changes. A policy that describes
       an older build is worse than none.
-->

# PIRT Privacy Policy

**Effective:** 27 July 2026
**Applies to:** the PIRT iOS app, version 0.1 and later.

## The short version

PIRT keeps your diary on your phone. There is no account, no server of
ours, and no analytics. We cannot read your visits, your notes, or your
photos, because they are never sent to us.

## What the app stores, and where

Everything the app records is written to your device's own storage:

- **Your visit log** — which curated place you stamped, when, whether you
  would go again, and any rating or note you added.
- **Photos you attach** — copied into the app's private storage on your
  device so they survive.
- **Your start place** — the station or landmark you pick for planning.

None of it is transmitted anywhere. Deleting the app deletes all of it.

## What we do not do

- No account, sign-up, login, or email address.
- No analytics, crash reporting, advertising, or tracking SDKs.
- No selling or sharing of personal information. We hold none to sell.
- No background location. No tracking of where you go.

## Permissions, and why

**Location (While Using the App).** When you tap to stamp a place, the app
reads your location once, at that moment, to show which nearby curated
places you might be at. That reading is used to sort a list and is then
discarded — it is never written to your diary, and never sent anywhere. The
app never requests background location, so it cannot see where you go when
it is closed. You can refuse this permission and search for places by name
instead; nothing else in the app changes.

**Photo Library.** Only when you tap to add a photo. The app receives the
image you pick and saves its own copy, re-encoded to drop the camera
metadata. It does not browse,
index, or upload your library. iOS lets you grant access to selected photos
only, and the app works normally that way.

## Maps

Maps are drawn using Apple Maps, which is part of iOS. Displaying a map
sends the map region being viewed to Apple, which is what makes the map
appear. That exchange is between your device and Apple and is covered by
[Apple's Privacy Policy](https://www.apple.com/legal/privacy/). We receive
nothing from it.

## Backups you create

The app can write a backup file containing your visits and your attached
photos, and hand it to the iOS share sheet so you can save or send it.

This only happens when you ask for it. Two things worth knowing:

- Photos are re-encoded when you attach them, which removes the camera
  metadata the original file carried — including the GPS coordinates and
  capture time a phone normally records. The copy in your diary, and in any
  backup, does not carry them. The original in your photo library is
  untouched.
- Once you send the file somewhere — Files, iCloud Drive, email, a
  messaging app — it is governed by that service's terms, not by this
  policy. Treat a backup like any other personal file.

## Device backups

If you back up your iPhone to iCloud or a computer, that backup includes
app data, the same as for other apps. Those backups are Apple's and are
controlled by your device's backup settings.

## Children

PIRT is not directed to children under 13, and we do not knowingly
collect information from them. Because the app has no account and collects
nothing, we hold no information about any user to identify or delete.

## Your rights, and deleting your data

Privacy laws including the GDPR and the California Consumer Privacy Act
(as amended by the CPRA) give you rights to access, correct, delete, and
port your personal information, and not to be discriminated against for
exercising them.

For PIRT those rights are satisfied directly on your device, because
we are not holding your data:

- **Access and portability** — Summary → Your diary → Back up writes your
  complete history to a file you own.
- **Deletion** — delete a visit in the app, or delete the app to remove
  everything at once. We have nothing to delete on our side.

If you believe we hold information about you and want to ask, contact us
below.

## Changes

If how the app handles data changes, this policy will be updated and the
effective date above will change. Material changes will be announced in the
app before they take effect.

## Contact

ansonal.lee@gmail.com
