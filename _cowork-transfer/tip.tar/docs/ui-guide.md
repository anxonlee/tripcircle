# PIRT UI Guide

Design reference for implementation. Treat every rule here as a hard constraint unless explicitly marked "preference." Companion to travel-planner-prd.md §6 (design requirements) and §6.1 (category colors). Where this guide and ad-hoc judgment conflict, this guide wins.

---

## 1. Design philosophy

1. **Planning-first, banner-free.** No ads, upsell strips, promo cards, feature announcements, or badges on core screens (map, plan, saved places, wishlist). If a screen element doesn't help the user plan or navigate, it doesn't ship.
2. **Light and airy.** White surfaces, soft map palette, generous whitespace. The map and the plan are the interface.
3. **One accent, spent carefully.** Clay (#D97757) appears only on the single primary action of a screen and the start-place identity. If clay appears twice on one screen for actions, something is wrong.
4. **Show the optimizer's reasoning.** Every generated plan visibly displays totals and tradeoffs. Never present an optimized result without its numbers.
5. **Calm density.** Compact but never cramped; nothing blinks, bounces, or begs.

---

## 2. Color tokens

### Core palette
| Token | Hex | Use |
|---|---|---|
| `surface` | #FFFFFF | Screens, cards, sheets, tab bar |
| `surfaceAlt` | #F6FAF8 | Summary chips, subtle wells |
| `surfaceInput` | #F1F3F4 | Segmented control track, mode chips |
| `border` | #F0F0F0 | Card borders (1px) |
| `borderStrong` | #E0E0E0 | Dividers, sheet grab handle |
| `textPrimary` | #1A1A1A | Headings, place names, values |
| `textSecondary` | #5F6368 | Meta text, ratings, leg details |
| `textMuted` | #80868B / #9AA0A6 | Timestamps, hints, inactive tab icons |
| `accent` | #D97757 | Primary action per screen; start-place pin |
| `positive` | #1D9E75 | Active tab, "Open now", selection highlight, Start day |
| `mapLand` | #E9F2EC | Map land base |
| `mapRoad` | #FFFFFF | Roads on map |
| `mapWater` | #CDE6F5 | Water |
| `mapBlock` | #DDE9DF | Building blocks |

### Category palette (fixed, max 7 — PRD §6.1)
| Category | Hex |
|---|---|
| Food | #E8542F |
| Historical / cultural | #E8A22F |
| Shopping | #2F7FE8 |
| Nature / outdoor | #1D9E75 |
| Nightlife | #8B5CF6 |
| (reserve 2 slots) | — |

Category color rules:
- A category's color is identical everywhere it appears (pin, tag, tile tint).
- **Multi-category = exactly two colors max.** 3+ categories → show the two primary ones; the rest only in the detail view.
- **Primary category first** (left half of split pin, first tag): the category the user saved the place for, else the venue's main POI type.
- **Color never carries meaning alone.** Tags always pair color with a text label; pins reveal a label on tap. (Colorblind accessibility is a hard requirement.)
- Tints for backgrounds: category color at ~10–16% opacity over white (e.g., `#E8542F` → `#E8542F18`-style alpha), icon or text in the full color.

### Dark mode
Out of scope for MVP. The app is light-locked for now; do not use OS-adaptive colors yet.

---

## 3. Typography

System font (SF Pro on iOS / Roboto on Android) — no custom fonts in MVP.

| Style | Size | Weight | Use |
|---|---|---|---|
| Screen title | 17–20 | 500 | Sheet headers ("Your Saturday out", "Day 1 · Kyoto") |
| Item title | 14 | 500 | Place names, stop names |
| Value | 15–16 | 500 | Summary numbers ($47, 25 min) |
| Body / meta | 12–13 | 400 | Category lines, ratings, times |
| Caption | 11 | 400–500 | Leg chips, tags, "Added by", warnings |
| Micro | 10 | 400 | Tab labels, pin labels |

Rules: weight 500 is the maximum (no bold-700 anywhere); color hierarchy (primary/secondary/muted) does the emphasis work, not weight or size jumps.

---

## 4. Layout patterns

### The canonical screen: map top, sheet bottom
- Map occupies the upper ~45% of the screen.
- Below it, a bottom sheet (white, 20px top radius, grab handle: 36×4px, `borderStrong`, centered) containing the list or timeline. Sheet overlaps the map by ~16–18px.
- Sheet header is sticky: title + context line on the left, the screen's single primary action button on the right.
- Floating on the map: pill search bar (top, 24px radius, subtle shadow `0 1px 4px rgba(0,0,0,0.08)`) and filter chips (below search, left-aligned).

### Spacing & shape
- Base spacing unit: 4. Screen side padding: 16. Card padding: 11–12. Gap between cards: 9–10.
- Radii: cards 14, icon tiles 12, buttons/pills 12–24 (fully rounded for pills/search), sheet 20, phone-frame-level containers 24+.
- Shadows: only on floating map elements and pins. Cards use 1px `border` instead of shadow.

### Bottom tab bar
- 5 items max; MVP uses 4: Explore, Saved, Trips, Profile (center "+" create button arrives with sharing).
- Active tab: `positive` color + 500 weight label. Inactive: `textMuted`.
- 56px height, white, 0.5px top border.

---

## 5. Components

### Map pins
- **Place pin:** 24–28px circle, category color fill, 2.5px white ring, shadow `0 1px 4px rgba(0,0,0,0.25)`.
- **Multi-category pin:** same circle split vertically into two halves (primary color left). Never more than two colors.
- **Numbered pin:** after optimization, pins show route order (white number, 13px/500) instead of plain fill. Numbering restarts per day.
- **Start-place pin:** clay circle with a white home glyph, 3px white ring. Visually distinct from all place pins; only one per map.
- **Selected state:** scale ~1.25 + raised z-index. Selecting a pin highlights its list card and vice versa (hard requirement).
- Tap reveals a small white label chip (10px text) under the pin with the place name.

### Route line
- Dashed polyline in `accent`, ~3.5px, dash pattern ≈ 2/7, rounded caps, ~0.9 opacity.
- Always a closed loop: start place → stops in order → back to start place.

### Place card (list)
Left → right: icon tile (44×44, radius 12, category tint background, category-colored icon; split-tint if two categories) · name (14/500) + meta line (star rating in Historical-amber, review count, category, price) + status line ("Open now" in `positive`, "Open til 21:00" in muted) · right-aligned distance (12/muted).
- Selected state: `positive` border + #F4FBF8 background.
- In wishlist contexts add: "Added by {name}" (11/muted) + upvote count in `positive`.

### Category tags
Pills: category color text on ~14% tint background with ~30% tint 1px border, 10–11px/500, radius 14. Multi-category → two pills side by side, primary first.

### Timeline (plan view)
- Vertical spine: 30px-wide gutter; stop nodes are 30px circles (category tint bg, category-colored number); between nodes a 2px `borderStrong` line.
- Start and end nodes: clay home circle. First row shows "Leave {time}", last leg reads "walk home {n} min".
- **Leg chip** between stops: `surfaceInput` pill, 11px, transport icon + "{mode} {duration} · {cost}" (omit cost when free).
- Each stop row: name (14/500), cost line (11/muted), right-aligned arrival time (12/secondary).

### Summary chips (optimizer transparency — required on every generated plan)
Row of 3 equal `surfaceAlt` cells, radius 10: label (11/muted) over value (15–16/500). Standard trio: total cost · travel time · "Home by {time}". Travel plans may substitute "saved 45 min" as a `positive` badge in the header.

### Balanced / Fastest toggle
Segmented control: `surfaceInput` track (radius 12, 3px padding), active segment white with subtle shadow and 500 weight, inactive transparent + `textSecondary`. Icons: scale (Balanced), bolt (Fastest). Toggling re-plans immediately and the summary chips visibly update — show the delta when feasible ("40 min faster · $18 more").

### Buttons
- **Primary (one per screen):** clay fill, white text, 13–15px/500, radius 12–20, icon + label. E.g., "Plan day", "Optimize", "Clone trip".
- **Positive action:** `positive` fill for go/confirm moments ("Start day").
- **Secondary:** white, 1px `borderStrong`, `textSecondary`.
- No text-only buttons for primary actions; no more than one filled button visible per screen region.

### Filter chips (on map)
Pills, 11px/500: active = `positive` fill + white text; inactive = white fill + `textSecondary`, subtle shadow. Single-select for the MVP.

### Warnings
Inline, never modal: 11px `#B8860B`-range warning text with a triangle icon under the affected stop ("Closes crowds by 11", "Over budget by $12"). Warnings inform; they never block.

---

## 6. Interaction rules

- **Pin ↔ card linking** is mandatory on every map+list screen: tapping either highlights both and scrolls the card into view.
- Toggles and filters apply instantly — no "Apply" buttons.
- Optimizer runs show a brief loading state on the primary button itself (spinner replacing icon), not a full-screen loader; target <10s per PRD F3.
- Drag-to-reorder in the timeline re-flows subsequent times immediately (when manual editing ships).
- Empty states are quiet and instructive (muted icon + one line + the primary action), never illustrated mascots or promos.
- Animations: 120–200ms ease transitions for selection and sheet movement only. Nothing auto-plays or loops.

## 7. Anti-patterns (never do these)

- Banners, upsells, badges, or announcements on core screens.
- Clay used for anything other than the screen's primary action and the start pin.
- Three or more colors on one pin/tile.
- Bold-700 text, ALL CAPS labels (except tiny caption labels are still sentence case), exclamation marks in UI copy.
- Modal interruptions during planning.
- Precise start-place address rendered anywhere in the UI beyond the user's own setup screen (privacy: neighborhood-level elsewhere, per PRD §3.1).
- Skeleton screens longer than ~1s; prefer instant mock-data rendering in dev.

## 8. Copy voice

Short, concrete, numeric. "Home by 17:00", "saved 45 min", "Leave by 9:20". No marketing adjectives ("amazing itinerary!"), no exclamation marks, no first-person app voice ("I found…"). Sentence case everywhere.
