/**
 * "$18" / "$1,340" — manual separator so we don't depend on Intl
 * availability. Whole dollars only: every cost in this app is an estimate,
 * and cents would imply a precision the model does not have.
 */
export function formatUsd(n: number): string {
  const rounded = Math.round(n);
  const sign = rounded < 0 ? '-' : '';
  const abs = Math.abs(rounded);
  return `${sign}$${String(abs).replace(/\B(?=(\d{3})+(?!\d))/g, ',')}`;
}

/**
 * TEMP FIXTURE: approximate, replace with live provider data.
 * The peg holds the Hong Kong dollar in a band, so a fixed rate is a fair
 * approximation, but it is still a hardcoded number and not a live quote.
 * `services/mock/transport.ts` imports this so the model has one rate.
 */
export const HKD_PER_USD = 7.8;

/**
 * "HK$8" / "HK$1,340". The planner scores in USD because every cost in the
 * model is `costUsd`; this converts at the edge, for display only. Nothing
 * upstream of the screen should ever see a Hong Kong dollar.
 */
export function formatHkd(usd: number): string {
  const rounded = Math.round(usd * HKD_PER_USD);
  const sign = rounded < 0 ? '-' : '';
  const abs = Math.abs(rounded);
  return `${sign}HK$${String(abs).replace(/\B(?=(\d{3})+(?!\d))/g, ',')}`;
}

/**
 * Day totals are shown to the nearest HK$5, because a day's cost is an
 * estimate assembled from other estimates and a figure like HK$237 claims a
 * precision it does not have.
 *
 * Rounding happens here, at display time, and nowhere else. Per-leg fares
 * stay exact so a HK$3 tram ride does not disappear into a HK$5 bucket, and
 * the optimiser's internal scoring never sees a rounded number.
 */
export function formatDayTotalHkd(usd: number): string {
  const hkdExact = usd * HKD_PER_USD;
  const snapped = Math.round(hkdExact / 5) * 5;
  return `HK$${String(snapped).replace(/\B(?=(\d{3})+(?!\d))/g, ',')}`;
}

/** "820" / "1.8k" / "3.1k" — compact counts. */
export function formatCount(n: number): string {
  return n >= 1000 ? `${(n / 1000).toFixed(1)}k` : String(n);
}

/** "45 min" / "1 h 32 min" */
export function formatDuration(min: number): string {
  const m = Math.round(min);
  if (m < 60) return `${m} min`;
  const h = Math.floor(m / 60);
  const rest = m % 60;
  return rest === 0 ? `${h} h` : `${h} h ${rest} min`;
}

/**
 * Coarse "how long ago" for a day count. Deliberately vague past a week —
 * a diary reads better as "3w ago" than a date nobody can place.
 */
export function relativeDays(days: number): string {
  if (days === 0) return 'today';
  if (days === 1) return 'yesterday';
  if (days < 7) return `${days}d ago`;
  if (days < 30) return `${Math.floor(days / 7)}w ago`;
  if (days < 365) return `${Math.floor(days / 30)}mo ago`;
  return `${Math.floor(days / 365)}y ago`;
}

/** 1st, 2nd, 3rd, 4th… for visit counts. */
export function ordinal(n: number): string {
  const rem100 = n % 100;
  if (rem100 >= 11 && rem100 <= 13) return `${n}th`;
  switch (n % 10) {
    case 1:
      return `${n}st`;
    case 2:
      return `${n}nd`;
    case 3:
      return `${n}rd`;
    default:
      return `${n}th`;
  }
}
