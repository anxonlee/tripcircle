import type { LatLng, CuratedPlace, StartPlace } from '../../../domain/types';
import { haversineKm } from '../../geo';
import { legOptions as mockLegOptions } from '../../../services/mock/transport';
import { hkPlaces } from '../../../services/mock/hkPlaces';
import { __internals, optimizeDay, type Goal, type OptimizeInput } from '../index';

const anchor: StartPlace = {
  id: 'anchor',
  name: 'Test Station',
  kind: 'station',
  location: { latitude: 22.28, longitude: 114.16 },
};

/** Deterministic walk-only world: 6 km/h, free. 0.009° lat ≈ 1.0 km. */
const walkOnly = (from: LatLng, to: LatLng) => {
  const km = haversineKm(from, to);
  return [{ mode: 'walk' as const, durationMin: Math.ceil(km * 10), costUsd: 0, distanceKm: km }];
};

function makePlace(id: string, latOffset: number, overrides: Partial<CuratedPlace> = {}): CuratedPlace {
  return {
    id,
    osmId: `node/test-${id}`,
    googlePlaceId: null,
    name: id,
    location: { latitude: 22.28 + latOffset, longitude: 114.16 },
    address: 'test',
    district: 'Central',
    themes: ['food'],
    visitDurationMin: 60,
    priceBand: 'free',
    avgCostUsd: 0,
    worthDetour: false,
    openHours: null,
    curator: 'test',
    curationStatus: 'published',
    ...overrides,
  };
}

function baseInput(overrides: Partial<OptimizeInput> = {}): OptimizeInput {
  return {
    startPlace: anchor,
    places: [],
    dayStartMin: 9 * 60,
    homeByMin: 21 * 60,
    goal: 'balanced',
    legOptions: walkOnly,
    ...overrides,
  };
}

const byId = (id: string): CuratedPlace => {
  const p = hkPlaces.find((x) => x.id === id);
  if (!p) throw new Error(`missing fixture place ${id}`);
  return p;
};

const centralAnchor: StartPlace = {
  id: 'lm-central-station',
  name: 'Central Station',
  kind: 'station',
  location: { latitude: 22.2818, longitude: 114.1578 },
};

/** Five real stops spread across the city — a plausible full HK day. */
const hkSubset = [
  byId('man-mo-temple'),
  byId('tst-promenade'),
  byId('mido-cafe'),
  byId('noonday-gun'),
  byId('apliu-street-market'),
];

const hkInput = (goal: Goal): OptimizeInput =>
  baseInput({
    startPlace: centralAnchor,
    places: hkSubset,
    goal,
    legOptions: mockLegOptions,
  });

// ——— Structure ————————————————————————————————————————————————————

describe('plan structure', () => {
  it('visits every selected place exactly once, round trip from the anchor', () => {
    const plan = optimizeDay(hkInput('balanced'));
    expect(plan.stops.map((s) => s.place.id).sort()).toEqual(
      hkSubset.map((p) => p.id).sort()
    );
    expect(plan.returnLeg).not.toBeNull();
    expect(plan.stops.map((s) => s.order)).toEqual([1, 2, 3, 4, 5]);
  });

  it('is deterministic', () => {
    const a = optimizeDay(hkInput('balanced'));
    const b = optimizeDay(hkInput('balanced'));
    expect(a).toEqual(b);
  });

  it('handles an empty selection with an empty plan', () => {
    const plan = optimizeDay(baseInput());
    expect(plan.stops).toEqual([]);
    expect(plan.returnLeg).toBeNull();
    expect(plan.homeMin).toBe(plan.dayStartMin);
    expect(plan.warnings).toEqual([]);
    expect(plan.totals.totalUsd).toBe(0);
  });

  it('keeps two places at identical coordinates as distinct stops', () => {
    const p1 = makePlace('twin-a', 0.01);
    const p2 = { ...makePlace('twin-b', 0.01), name: 'twin-b' };
    const plan = optimizeDay(baseInput({ places: [p1, p2] }));
    expect(plan.stops.map((s) => s.place.id).sort()).toEqual(['twin-a', 'twin-b']);
  });

  it('reports internally consistent times', () => {
    const plan = optimizeDay(hkInput('balanced'));
    let t = plan.dayStartMin;
    for (const s of plan.stops) {
      expect(s.arriveMin).toBe(t + s.leg.durationMin);
      expect(s.beginMin).toBe(s.arriveMin + s.waitMin);
      expect(s.departMin).toBe(s.beginMin + s.place.visitDurationMin);
      t = s.departMin;
    }
    expect(plan.homeMin).toBe(t + plan.returnLeg!.durationMin);
  });
});

// ——— Ordering quality ————————————————————————————————————————————

describe('tour ordering (NN + 2-opt)', () => {
  it('2-opt never worsens the nearest-neighbor tour, and beats dataset order', () => {
    const { buildWeights, nearestNeighborTour, twoOpt, tourWeight } = __internals;
    const w = buildWeights(
      centralAnchor.location,
      hkSubset,
      'balanced',
      mockLegOptions
    );
    const identity = hkSubset.map((_, i) => i + 1);
    const nn = nearestNeighborTour(w);
    const opt = twoOpt(nn, w);
    expect(tourWeight(opt, w)).toBeLessThanOrEqual(tourWeight(nn, w) + 1e-9);
    expect(tourWeight(opt, w)).toBeLessThanOrEqual(tourWeight(identity, w) + 1e-9);
  });

  it('orders geographically sensible lines end-to-end (no backtracking)', () => {
    // Five stops on a north line: any optimal walk visits them in order.
    const line = [0.01, 0.02, 0.03, 0.04, 0.05].map((off, i) =>
      makePlace(`line-${i}`, off)
    );
    const shuffled = [line[3], line[0], line[4], line[1], line[2]];
    const plan = optimizeDay(baseInput({ places: shuffled }));
    expect(plan.stops.map((s) => s.place.id)).toEqual([
      'line-0',
      'line-1',
      'line-2',
      'line-3',
      'line-4',
    ]);
  });
});

// ——— Transport choice —————————————————————————————————————————————

describe('per-leg transport choice', () => {
  /**
   * Both ends stay on the Kowloon side of Victoria Harbour, so these
   * exercise mode choice alone — a cross-harbour leg has its own penalties
   * and withdraws walking entirely.
   */
  const near = (km: number): [LatLng, LatLng] => [
    { latitude: 22.30, longitude: 114.17 },
    { latitude: 22.30 + km / 111.19, longitude: 114.17 },
  ];

  it('balanced walks short legs and takes the MTR on long legs', () => {
    const [a, b] = near(1.0);
    expect(__internals.chooseLeg(mockLegOptions(a, b), 'balanced').mode).toBe('walk');
    const [c, d] = near(3.0);
    expect(__internals.chooseLeg(mockLegOptions(c, d), 'balanced').mode).toBe('mtr');
  });

  it('fastest takes a taxi where it is decisively quicker', () => {
    // 2.5 km is past walking range but short enough that the taxi's lack of
    // station access still wins it 5 minutes. The window is narrow by
    // design: the MTR is the faster mode per kilometre and only loses on
    // fixed overhead, so beyond ~3.6 km the taxi no longer clears the
    // optimizer's four-minute tolerance and the cheaper rail leg wins.
    const [a, b] = near(2.5);
    expect(__internals.chooseLeg(mockLegOptions(a, b), 'fastest').mode).toBe('taxi');
  });

  it('fastest refuses a taxi that saves almost nothing (short hop → walk)', () => {
    const [a, b] = near(0.5);
    expect(__internals.chooseLeg(mockLegOptions(a, b), 'fastest').mode).toBe('walk');
  });

  it('fastest plan is never slower, balanced plan is never pricier', () => {
    const balanced = optimizeDay(hkInput('balanced'));
    const fastest = optimizeDay(hkInput('fastest'));
    expect(fastest.totals.travelMin).toBeLessThanOrEqual(balanced.totals.travelMin);
    expect(balanced.totals.travelUsd).toBeLessThanOrEqual(fastest.totals.travelUsd);
  });
});

// ——— Open hours ———————————————————————————————————————————————————

describe('open hours', () => {
  it('waits for a place that has not opened yet and says so', () => {
    const cafe = makePlace('late-cafe', 0.009, {
      openHours: { open: 10 * 60, close: 22 * 60 },
    });
    const plan = optimizeDay(baseInput({ places: [cafe] }));
    const stop = plan.stops[0];
    expect(stop.beginMin).toBe(10 * 60);
    expect(stop.waitMin).toBeGreaterThan(0);
    expect(plan.warnings.join(' ')).toContain('opens at 10:00');
  });

  it('warns when a stop is reached after closing', () => {
    const earlyBird = makePlace('early-bird', 0.09, {
      openHours: { open: 5 * 60, close: 9 * 60 + 30 }, // closes 9:30, 10km away
    });
    const plan = optimizeDay(baseInput({ places: [earlyBird] }));
    expect(plan.warnings.join(' ')).toMatch(/after .*closes/);
  });

  it('reorders the day to rescue a stop that would be reached after closing', () => {
    const lazyMuseum = makePlace('lazy-museum', 0.005, {
      visitDurationMin: 180, // long first visit that would sink the next stop
    });
    const earlyMarket = makePlace('early-market', 0.02, {
      openHours: { open: 5 * 60, close: 11 * 60 },
      visitDurationMin: 60,
    });
    const plan = optimizeDay(baseInput({ places: [lazyMuseum, earlyMarket] }));
    expect(plan.stops[0].place.id).toBe('early-market');
    expect(plan.warnings.filter((w) => /after .*closes/.test(w))).toEqual([]);
  });
});

// ——— Cost, reported rather than enforced ——————————————————————————

describe('cost reporting', () => {
  it('keeps a day cheap through the goal, not through a cap', () => {
    // Was 'downgrades taxi legs to cheaper modes to get under the cap'. The
    // cap is gone, but the need it served is not: on the same expensive leg
    // where Fastest buys a taxi, Economic must decline it by construction.
    // ~2.5 km: the band where Fastest genuinely buys a taxi. Further out the
    // MTR is quicker anyway, so there would be no expensive choice to decline.
    // Southward so the leg stays on Hong Kong Island: a cross-harbour leg
    // carries tunnel penalties that close the taxi's time advantage.
    const far = makePlace('far-spot', -0.0225);
    const shared = { places: [far], legOptions: mockLegOptions };
    const fastest = optimizeDay(baseInput({ ...shared, goal: 'fastest' }));
    const economic = optimizeDay(baseInput({ ...shared, goal: 'economic' }));

    expect(fastest.stops[0].leg.mode).toBe('taxi');
    expect([economic.stops[0].leg.mode, economic.returnLeg!.mode]).not.toContain('taxi');
    expect(economic.totals.travelUsd).toBeLessThan(fastest.totals.travelUsd);
  });

  it('reports total cost as travel plus at-place spend, and never warns on it', () => {
    // Was 'warns when the cap is unreachable (spend alone exceeds it)'. The
    // warning is gone; the arithmetic it depended on is the thing worth
    // keeping, since cost visibility survived the cap's removal.
    const pricey = makePlace('pricey', 0.009, { avgCostUsd: 50 });
    const plan = optimizeDay(baseInput({ places: [pricey] }));
    expect(plan.totals.spendUsd).toBe(50);
    expect(plan.totals.totalUsd).toBe(plan.totals.travelUsd + plan.totals.spendUsd);
    expect(plan.warnings.join(' ')).not.toContain('budget');
  });

  it('costs every leg individually so cost stays visible per leg', () => {
    const plan = optimizeDay(hkInput('balanced'));
    for (const s of plan.stops) {
      expect(typeof s.leg.costUsd).toBe('number');
      expect(s.leg.costUsd).toBeGreaterThanOrEqual(0);
    }
    const legSum =
      plan.stops.reduce((n, s) => n + s.leg.costUsd, 0) + plan.returnLeg!.costUsd;
    expect(plan.totals.travelUsd).toBe(legSum);
  });
});

// ——— Day window ———————————————————————————————————————————————————

describe('day window', () => {
  it('warns when the plan gets home past the target', () => {
    const plan = optimizeDay({ ...hkInput('balanced'), homeByMin: 10 * 60 });
    expect(plan.warnings.join(' ')).toContain('past your 10:00 target');
  });
});

// ——— Scale ————————————————————————————————————————————————————————

describe('scale', () => {
  /**
   * Times each goal separately, which is what the name has always claimed.
   * It previously wrapped both solves in one timer and asserted the pair came
   * in under a second — a bar the dataset crossed at 53 places, since a single
   * solve is ~300ms here and two plus JIT warm-up runs past 1000ms.
   *
   * Worth knowing that this cost grows faster than the place count: 20 places
   * solve in ~24ms, 41 in ~178ms, 53 in ~302ms. Roughly cubic, because the
   * weight matrix is O(n²) and every cell asks the transport model for all
   * six modes. A curated city of a few hundred places would need this looked
   * at; at demo scale it is fine.
   */
  it('plans the whole HK dataset in well under a second per goal', () => {
    for (const goal of ['balanced', 'fastest'] as const) {
      const t0 = Date.now();
      const plan = optimizeDay({ ...hkInput(goal), places: hkPlaces });
      const elapsed = Date.now() - t0;
      expect(plan.stops).toHaveLength(hkPlaces.length);
      expect(elapsed).toBeLessThan(1000);
    }
  });
});
