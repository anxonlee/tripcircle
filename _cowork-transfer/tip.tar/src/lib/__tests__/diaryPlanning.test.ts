import type { Visit } from '../../domain/diary';
import type { StartPlace } from '../../domain/types';
import { hkPlaces } from '../../services/mock/hkPlaces';
import {
  MAX_STOPS,
  MIN_STOPS,
  REASON_PREVALENCE_MAX,
  SUGGESTION_HISTORY_THRESHOLD,
  deriveStopCount,
  suppressCommonReasons,
  distinctPlacesVisited,
  hasEnoughHistory,
  rankPlaces,
  suggestDay,
} from '../planner';
import { findOverdue, startOfWeek, summarizeWeek } from '../summary';
import { fitTransform, layoutWall, CARD_W } from '../wallLayout';
import { buildWallCards } from '../../domain/diary';

const DAY = 86_400_000;
/** A Wednesday, so week boundaries are visible in the assertions. */
const NOW = new Date('2026-07-29T12:00:00').getTime();

const tst: StartPlace = {
  id: 'lm-tst-station',
  name: 'Tsim Sha Tsui Station',
  kind: 'station',
  location: { latitude: 22.2977, longitude: 114.1722 },
};

function visit(placeId: string, daysAgo: number, overrides: Partial<Visit> = {}): Visit {
  return {
    id: `v-${placeId}-${daysAgo}-${Math.random()}`,
    placeId,
    timestamp: NOW - daysAgo * DAY,
    wouldGoAgain: 'yes',
    ...overrides,
  };
}

describe('week boundaries', () => {
  it('starts the week on Monday at midnight', () => {
    const start = new Date(startOfWeek(NOW));
    expect(start.getDay()).toBe(1);
    expect(start.getHours()).toBe(0);
    expect(start.getMinutes()).toBe(0);
  });

  it('treats a Sunday as belonging to the week that began six days earlier', () => {
    const sunday = new Date('2026-08-02T20:00:00').getTime();
    expect(startOfWeek(sunday)).toBe(startOfWeek(NOW));
  });
});

describe('weekly summary', () => {
  it('is empty and harmless for a diary with no visits', () => {
    const s = summarizeWeek(hkPlaces, [], NOW);
    expect(s.visitCount).toBe(0);
    expect(s.placeCount).toBe(0);
    expect(s.districts).toEqual([]);
    expect(s.goAgain).toEqual([]);
    expect(s.overdue).toBeNull();
  });

  it('counts only visits inside the current week', () => {
    const visits = [
      visit('mido-cafe', 1), // this week
      visit('kam-wah-cafe', 2), // this week
      visit('man-mo-temple', 10), // last week
    ];
    const s = summarizeWeek(hkPlaces, visits, NOW);
    expect(s.visitCount).toBe(2);
    expect(s.placeCount).toBe(2);
  });

  it('counts repeat visits to one place once in placeCount', () => {
    const visits = [visit('mido-cafe', 0), visit('mido-cafe', 1)];
    const s = summarizeWeek(hkPlaces, visits, NOW);
    expect(s.visitCount).toBe(2);
    expect(s.placeCount).toBe(1);
  });

  it('flags a place as new only on the week it was first stamped', () => {
    const returning = [visit('mido-cafe', 90), visit('mido-cafe', 1)];
    expect(summarizeWeek(hkPlaces, returning, NOW).newPlaceCount).toBe(0);

    const firstTime = [visit('mido-cafe', 1)];
    expect(summarizeWeek(hkPlaces, firstTime, NOW).newPlaceCount).toBe(1);
  });

  it('collects districts and ranks themes by frequency', () => {
    const visits = [
      visit('tim-ho-wan-ssp', 1), // Sham Shui Po, food
      visit('kung-wo-dou-bun-chong', 1), // Sham Shui Po, food
      visit('man-mo-temple', 2), // Central, historical
    ];
    const s = summarizeWeek(hkPlaces, visits, NOW);
    expect(s.districts.sort()).toEqual(['Central', 'Sham Shui Po']);
    expect(s.themes[0]).toEqual({ theme: 'food', count: 2 });
  });

  it('lists only would-go-again yes places as highlights', () => {
    const visits = [
      visit('mido-cafe', 1, { wouldGoAgain: 'yes' }),
      visit('sogo-causeway-bay', 1, { wouldGoAgain: 'no' }),
    ];
    const s = summarizeWeek(hkPlaces, visits, NOW);
    expect(s.goAgain.map((p) => p.id)).toEqual(['mido-cafe']);
  });

  it('counts photos attached to this week\'s visits', () => {
    const visits = [
      visit('mido-cafe', 1, { photoUri: 'file:///a.jpg' }),
      visit('kam-wah-cafe', 1),
      visit('man-mo-temple', 20, { photoUri: 'file:///old.jpg' }),
    ];
    expect(summarizeWeek(hkPlaces, visits, NOW).photoCount).toBe(1);
  });
});

describe('overdue nudge', () => {
  it('surfaces a loved place not visited in a long time', () => {
    const visits = [visit('man-mo-temple', 120, { wouldGoAgain: 'yes' })];
    const overdue = findOverdue(hkPlaces, visits, NOW);
    expect(overdue?.place.id).toBe('man-mo-temple');
    expect(overdue?.daysSince).toBe(120);
  });

  it('never nudges toward a place the user said no to', () => {
    const visits = [visit('sogo-causeway-bay', 200, { wouldGoAgain: 'no' })];
    expect(findOverdue(hkPlaces, visits, NOW)).toBeNull();
  });

  it('ignores places visited recently', () => {
    const visits = [visit('man-mo-temple', 5, { wouldGoAgain: 'yes' })];
    expect(findOverdue(hkPlaces, visits, NOW)).toBeNull();
  });

  it('picks the longest-neglected of several candidates', () => {
    const visits = [
      visit('man-mo-temple', 70, { wouldGoAgain: 'yes' }),
      visit('kam-wah-cafe', 300, { wouldGoAgain: 'yes' }),
    ];
    expect(findOverdue(hkPlaces, visits, NOW)?.place.id).toBe('kam-wah-cafe');
  });
});

describe('suggestion history gate', () => {
  it('counts distinct places, not stamps', () => {
    const visits = [
      visit('mido-cafe', 1),
      visit('mido-cafe', 5),
      visit('mido-cafe', 9),
      visit('kam-wah-cafe', 2),
    ];
    expect(distinctPlacesVisited(visits)).toBe(2);
  });

  it('stays shut for an empty diary', () => {
    expect(hasEnoughHistory([])).toBe(false);
  });

  it('stays shut for one place stamped many times', () => {
    const visits = [1, 5, 9, 14, 20].map((d) => visit('mido-cafe', d));
    expect(visits.length).toBeGreaterThan(SUGGESTION_HISTORY_THRESHOLD);
    expect(hasEnoughHistory(visits)).toBe(false);
  });

  it('stays shut one place short of the threshold', () => {
    const visits = ['mido-cafe', 'kam-wah-cafe', 'man-mo-temple'].map((id) =>
      visit(id, 3)
    );
    expect(visits).toHaveLength(SUGGESTION_HISTORY_THRESHOLD - 1);
    expect(hasEnoughHistory(visits)).toBe(false);
  });

  it('opens at four distinct places', () => {
    const visits = [
      'mido-cafe',
      'kam-wah-cafe',
      'man-mo-temple',
      'ladies-market',
    ].map((id) => visit(id, 3));
    expect(hasEnoughHistory(visits)).toBe(true);
  });
});

describe('thin planner ranking', () => {
  it('drops places too far from the anchor to belong in a local day', () => {
    // From Sham Shui Po, Tai Hang in Causeway Bay is ~6.5km — across the
    // harbour and the whole island, not a walkable day out from here.
    const shamShuiPo: StartPlace = {
      id: 'lm-sham-shui-po-station',
      name: 'Sham Shui Po Station',
      kind: 'station',
      location: { latitude: 22.3306, longitude: 114.1622 },
    };
    const ids = rankPlaces(hkPlaces, [], shamShuiPo, NOW).map((r) => r.place.id);
    expect(ids).not.toContain('lin-fa-temple');
    expect(ids).toContain('apliu-street-market'); // right there on the doorstep
  });

  it('keeps most of the city in range from a central anchor', () => {
    // HK's core is compact: a TST anchor should reach nearly everything curated.
    const ranked = rankPlaces(hkPlaces, [], tst, NOW);
    expect(ranked.length).toBeGreaterThan(hkPlaces.length * 0.8);
  });

  it('ranks a loved, long-unvisited place above an equivalent unstamped one', () => {
    const visits = [
      visit('kam-wah-cafe', 90, { wouldGoAgain: 'yes' }),
      visit('kam-wah-cafe', 120, { wouldGoAgain: 'yes' }),
    ];
    const ranked = rankPlaces(hkPlaces, visits, tst, NOW);
    const loved = ranked.findIndex((r) => r.place.id === 'kam-wah-cafe');
    const unstamped = ranked.findIndex((r) => r.place.id === 'kwan-kee-store');
    expect(loved).toBeLessThan(unstamped);
  });

  it('pushes down somewhere visited yesterday', () => {
    const fresh = rankPlaces(
      hkPlaces,
      [visit('kam-wah-cafe', 1, { wouldGoAgain: 'yes' })],
      tst,
      NOW
    );
    const cold = rankPlaces(hkPlaces, [], tst, NOW);
    const freshRank = fresh.findIndex((r) => r.place.id === 'kam-wah-cafe');
    const coldRank = cold.findIndex((r) => r.place.id === 'kam-wah-cafe');
    expect(freshRank).toBeGreaterThan(coldRank);
  });

  it('demotes a place the user said no to', () => {
    const ranked = rankPlaces(
      hkPlaces,
      [visit('kam-wah-cafe', 30, { wouldGoAgain: 'no' })],
      tst,
      NOW
    );
    const disliked = ranked.find((r) => r.place.id === 'kam-wah-cafe')!;
    const median = ranked[Math.floor(ranked.length / 2)];
    expect(disliked.score).toBeLessThan(median.score);
  });

  it('never consults Google fields — ranking survives on curation alone', () => {
    const ranked = rankPlaces(hkPlaces, [], tst, NOW);
    // worthDetour is the only editorial boost with an empty diary, so the
    // top of the list must be a worth-a-detour place.
    expect(ranked[0].place.worthDetour).toBe(true);
    expect(ranked[0].reasons).toContain('Worth a detour');
  });

  it('explains every suggestion it makes', () => {
    // A diary, not an empty one: suggestions are gated on four distinct
    // places, so an empty diary is a state the product no longer reaches.
    // The assertion is the original — every card carries a reason.
    const visits = [
      visit('mido-cafe', 3),
      visit('kam-wah-cafe', 7),
      visit('man-mo-temple', 11),
      visit('ladies-market', 14),
    ];
    expect(hasEnoughHistory(visits)).toBe(true);
    for (const s of suggestDay(hkPlaces, visits, tst, 4, NOW)) {
      expect(s.reasons.length).toBeGreaterThan(0);
    }
  });
});

describe('displayed reasons must discriminate', () => {
  /** Four places, all stamped within the last fortnight. */
  const recent = [
    visit('mido-cafe', 3),
    visit('kam-wah-cafe', 7),
    visit('man-mo-temple', 11),
    visit('ladies-market', 14),
  ];

  const prevalence = (ranked: ReturnType<typeof rankPlaces>, text: string) =>
    ranked.filter((r) => r.reasons.includes(text)).length / ranked.length;

  it('leaves the ranking unsuppressed, so curation is still visible there', () => {
    const ranked = rankPlaces(hkPlaces, recent, tst, NOW);
    expect(prevalence(ranked, 'Worth a detour')).toBeGreaterThan(
      REASON_PREVALENCE_MAX
    );
  });

  it('drops a reason true of most of the candidate set', () => {
    const shown = suppressCommonReasons(rankPlaces(hkPlaces, [], tst, NOW));
    // Both of the reasons an empty diary can produce are far too common:
    // "Somewhere new" on all 53, "Worth a detour" on 26.
    expect(shown.every((s) => !s.reasons.includes('Somewhere new'))).toBe(true);
    expect(shown.every((s) => !s.reasons.includes('Worth a detour'))).toBe(true);
  });

  it('keeps every surviving reason under the threshold', () => {
    const shown = suppressCommonReasons(rankPlaces(hkPlaces, recent, tst, NOW));
    const counts = new Map<string, number>();
    for (const s of shown) {
      for (const r of s.reasons) counts.set(r, (counts.get(r) ?? 0) + 1);
    }
    for (const [, c] of counts) {
      expect(c / shown.length).toBeLessThanOrEqual(REASON_PREVALENCE_MAX);
    }
  });

  it('protects a reason earned from the diary even if it spreads', () => {
    // Stamp enough of one district that its affinity label would otherwise
    // breach the threshold on that district's places.
    const ranked = rankPlaces(hkPlaces, recent, tst, NOW);
    const shown = suppressCommonReasons(ranked);
    const earned = shown.flatMap((s) =>
      s.reasonDetail.filter((r) => r.fromDiary)
    );
    const beforeCount = ranked.flatMap((s) =>
      s.reasonDetail.filter((r) => r.fromDiary)
    ).length;
    expect(earned).toHaveLength(beforeCount);
  });

  it('measures prevalence per reason kind, not per string', () => {
    // "Not since 2 months ago" and "Not since 4 months ago" are one reason.
    // Counting the strings apart would halve what the rule sees.
    const old = [
      visit('mido-cafe', 60),
      visit('kam-wah-cafe', 80),
      visit('man-mo-temple', 100),
      visit('ladies-market', 120),
    ];
    const texts = new Set(
      rankPlaces(hkPlaces, old, tst, NOW)
        .flatMap((s) => s.reasonDetail)
        .filter((r) => r.kind === 'overdue')
        .map((r) => r.text)
    );
    expect(texts.size).toBeGreaterThan(1);
  });

  it('puts an explainable candidate above one with nothing left to say', () => {
    const day = suggestDay(hkPlaces, recent, tst, 4, NOW);
    expect(day).toHaveLength(4);
    for (const s of day) expect(s.reasons.length).toBeGreaterThan(0);
  });

  it('earns a reason from proximity to somewhere the user liked', () => {
    const shown = suppressCommonReasons(rankPlaces(hkPlaces, recent, tst, NOW));
    expect(
      shown.some((s) => s.reasons.includes('Near somewhere you liked'))
    ).toBe(true);
  });

  it('says nothing about a district visited only once', () => {
    const oneEach = [
      visit('mido-cafe', 5), // Yau Ma Tei
      visit('man-mo-temple', 6), // Central
      visit('sogo-causeway-bay', 7), // Causeway Bay
      visit('apliu-street-market', 8), // Sham Shui Po
    ];
    const ranked = rankPlaces(hkPlaces, oneEach, tst, NOW);
    expect(
      ranked.some((s) => s.reasons.includes('A district you keep returning to'))
    ).toBe(false);
  });
});

describe('recency penalty', () => {
  it('does not suggest going straight back to somewhere from last week', () => {
    // The old penalty switched off after three days, so a place stamped a
    // fortnight ago kept its would-go-again and frequency boosts unopposed
    // and outranked everywhere unvisited.
    const visits = [
      visit('mido-cafe', 3),
      visit('kam-wah-cafe', 7),
      visit('man-mo-temple', 11),
      visit('ladies-market', 14),
    ];
    const day = suggestDay(hkPlaces, visits, tst, 4, NOW);
    const stamped = new Set(visits.map((v) => v.placeId));
    expect(day.every((s) => !stamped.has(s.place.id))).toBe(true);
  });

  it('tapers rather than switching off, so nearer visits are pushed down further', () => {
    const rankOf = (daysAgo: number) =>
      rankPlaces(
        hkPlaces,
        [visit('kam-wah-cafe', daysAgo, { wouldGoAgain: 'yes' })],
        tst,
        NOW
      ).find((r) => r.place.id === 'kam-wah-cafe')!.score;

    expect(rankOf(2)).toBeLessThan(rankOf(20));
    expect(rankOf(20)).toBeLessThan(rankOf(40));
  });

  it('still lifts a loved place once it is past the revisit window', () => {
    const ranked = rankPlaces(
      hkPlaces,
      [visit('kam-wah-cafe', 90, { wouldGoAgain: 'yes' })],
      tst,
      NOW
    );
    const revisit = ranked.find((r) => r.place.id === 'kam-wah-cafe')!;
    expect(revisit.reasons).toContain('Not since 3 months ago');
  });
});

describe('stop count derived from the day window', () => {
  const ranked = () => rankPlaces(hkPlaces, [], tst, NOW);
  const at = (dayStartMin: number, homeByMin: number) =>
    deriveStopCount(ranked(), { dayStartMin, homeByMin });

  it('gives a short afternoon fewer stops than a full day', () => {
    expect(at(12 * 60, 15 * 60)).toBeLessThan(at(9 * 60, 24 * 60));
  });

  it('never derives fewer than two, however short the window', () => {
    expect(at(9 * 60, 9 * 60 + 20)).toBe(MIN_STOPS);
    expect(at(9 * 60, 9 * 60)).toBe(MIN_STOPS);
  });

  it('never derives more than the cap, however long the window', () => {
    expect(at(0, 24 * 60)).toBeLessThanOrEqual(MAX_STOPS);
  });

  it('buys fewer stops per hour once the hours stop being open ones', () => {
    // Adding the six hours from 03:00 to 09:00 adds almost no open time, so
    // it must not derive the stops a six-hour daytime extension would.
    const daytime = at(9 * 60, 15 * 60);
    const overnightExtension = at(3 * 60, 15 * 60) - daytime;
    const daytimeExtension = at(9 * 60, 21 * 60) - daytime;
    expect(overnightExtension).toBeLessThan(daytimeExtension);
  });

  it('derives nothing from an empty candidate set', () => {
    expect(deriveStopCount([], { dayStartMin: 9 * 60, homeByMin: 24 * 60 })).toBe(0);
  });

  it('is what suggestDay uses when handed a window', () => {
    const window = { dayStartMin: 10 * 60, homeByMin: 18 * 60 };
    const day = suggestDay(hkPlaces, [], tst, window, NOW);
    expect(day).toHaveLength(deriveStopCount(ranked(), window));
  });

  it('still honours an explicit count, which is what the tests pass', () => {
    expect(suggestDay(hkPlaces, [], tst, 3, NOW)).toHaveLength(3);
  });
});

describe('suggestDay', () => {
  it('returns the requested number of places', () => {
    expect(suggestDay(hkPlaces, [], tst, 4, NOW)).toHaveLength(4);
  });

  it('does not build a day out of five of the same theme', () => {
    const day = suggestDay(hkPlaces, [], tst, 4, NOW);
    const counts = new Map<string, number>();
    for (const s of day) {
      const t = s.place.themes[0];
      counts.set(t, (counts.get(t) ?? 0) + 1);
    }
    for (const n of counts.values()) expect(n).toBeLessThanOrEqual(2);
  });

  it('is deterministic for the same diary', () => {
    const a = suggestDay(hkPlaces, [], tst, 4, NOW).map((s) => s.place.id);
    const b = suggestDay(hkPlaces, [], tst, 4, NOW).map((s) => s.place.id);
    expect(a).toEqual(b);
  });
});

describe('wall layout', () => {
  const cards = (ids: [string, number][]) =>
    buildWallCards(
      hkPlaces,
      ids.map(([id, days]) => visit(id, days)),
      NOW
    );

  it('is empty for an empty diary', () => {
    const layout = layoutWall([]);
    expect(layout.cards).toEqual([]);
    expect(layout.width).toBe(0);
  });

  it('groups cards by district', () => {
    const layout = layoutWall(
      cards([
        ['ladies-market', 1], // Mong Kok
        ['kam-wah-cafe', 2], // Mong Kok
        ['man-mo-temple', 3], // Central
      ])
    );
    expect(layout.clusters.map((c) => c.district)).toEqual(['Mong Kok', 'Central']);
  });

  it('gives every card a distinct position', () => {
    const layout = layoutWall(
      cards([
        ['ladies-market', 1],
        ['kam-wah-cafe', 2],
        ['mido-cafe', 3],
        ['man-mo-temple', 4],
      ])
    );
    const keys = layout.cards.map((c) => `${c.x},${c.y}`);
    expect(new Set(keys).size).toBe(keys.length);
  });

  it('keeps a card tilted but only slightly, and always the same way', () => {
    const first = layoutWall(cards([['mido-cafe', 1]])).cards[0];
    const second = layoutWall(cards([['mido-cafe', 1]])).cards[0];
    expect(first.tilt).toBe(second.tilt);
    expect(Math.abs(first.tilt)).toBeLessThanOrEqual(3.5);
  });

  it('fit never zooms past 1:1 for a nearly empty board', () => {
    const layout = layoutWall(cards([['mido-cafe', 1]]));
    const t = fitTransform(layout, { width: 390, height: 700 });
    expect(t.scale).toBeLessThanOrEqual(1);
    expect(t.scale).toBeGreaterThan(0);
  });

  it('fit shrinks a large board to fit the viewport', () => {
    const many = hkPlaces.slice(0, 20).map((p, i) => [p.id, i + 1] as [string, number]);
    const layout = layoutWall(cards(many));
    const viewport = { width: 390, height: 700 };
    const t = fitTransform(layout, viewport);
    expect(layout.width * t.scale).toBeLessThanOrEqual(viewport.width);
    expect(layout.height * t.scale).toBeLessThanOrEqual(viewport.height);
  });

  it('centers the board within the viewport', () => {
    const layout = layoutWall(cards([['mido-cafe', 1]]));
    const viewport = { width: 390, height: 700 };
    const t = fitTransform(layout, viewport);
    const right = t.translateX + layout.width * t.scale;
    expect(Math.round(t.translateX)).toBe(Math.round(viewport.width - right));
  });

  it('sizes a cluster wide enough for its cards', () => {
    // Both in Mong Kok, so they land in one cluster.
    const layout = layoutWall(
      cards([
        ['ladies-market', 1],
        ['kam-wah-cafe', 2],
      ])
    );
    expect(layout.clusters[0].width).toBeGreaterThanOrEqual(CARD_W * 2);
  });
});
