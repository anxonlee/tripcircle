import { aggregateAll, type PlaceStats, type Visit } from '../domain/diary';
import type { CuratedPlace, StartPlace } from '../domain/types';
import { haversineKm } from './geo';

/**
 * The thin planner (PRD FD5) — "a simple optimized day out from the curated
 * dataset and the user's frequency/recency history."
 *
 * This module only CHOOSES which places belong in a day; ordering, transport,
 * and timing stay with the optimizer. Keeping selection separate is what lets
 * the full Balanced/Fastest optimizer arrive in Phase 2 without touching the
 * ranking logic.
 *
 * ⚠️ The scoring inputs are deliberately limited to Foundation + Curation +
 * the user's own diary. Google ratings and review counts are never consulted:
 * §12.2 forbids feeding stored Google values to the optimizer, and the whole
 * premise is that our curation plus your history beats a crowd average.
 */

/**
 * What kind of claim a reason makes. Prevalence is measured per kind rather
 * than per string, because "Not since 2 months ago" and "Not since 4 months
 * ago" are one label wearing two coats: counting the strings separately would
 * halve the measured prevalence of a reason that is really one reason.
 */
export type ReasonKind =
  | 'detour'
  | 'new'
  | 'regular'
  | 'overdue'
  | 'nearLoved'
  | 'district';

export interface Reason {
  kind: ReasonKind;
  /** What the user reads. */
  text: string;
  /**
   * Earned from the user's own record rather than from the dataset. These are
   * specific by construction and §3.3.0.3 says to protect them.
   */
  fromDiary: boolean;
}

export interface Suggestion {
  place: CuratedPlace;
  score: number;
  /** Why this place is in the day — shown to the user, per PRD §1.3.3. */
  reasons: string[];
  /** The same reasons with their kind, which is what suppression works on. */
  reasonDetail: Reason[];
}

/** What the diary says about the user, computed once per ranking. */
interface DiaryContext {
  /** Places they have stamped and would go back to. */
  loved: CuratedPlace[];
  /** The district they keep returning to, if there is one. */
  topDistrict: string | null;
}

interface ScoreContext {
  stats: PlaceStats | undefined;
  anchorKm: number;
  diary: DiaryContext;
}

/** Days after which a loved place becomes a "you haven't been in a while". */
const REVISIT_SWEET_SPOT_DAYS = 45;
/** Beyond this from the anchor, a place is a poor fit for a local day out. */
const MAX_ANCHOR_KM = 6;
/** Close enough to somewhere they liked to be worth mentioning. */
const NEAR_LOVED_KM = 0.4;
/** Visits to one district before it counts as somewhere they keep returning to. */
const DISTRICT_AFFINITY_MIN = 2;

/**
 * A reason is shown only if it is true of this share of the candidates or
 * fewer (PRD §3.3.0.3). "Somewhere new" once appeared on 49 of 53 places,
 * which is noise wearing the costume of an explanation.
 */
export const REASON_PREVALENCE_MAX = 0.25;

/**
 * Distinct places the user must have visited before the Plan tab offers
 * suggestions (PRD §3.3.0.1). One stamp is not something to rank on, and
 * suggesting from it reproduces the vacuous-reason problem at a smaller
 * scale. The threshold is recorded here rather than in the screen so it can
 * be tuned and tested in one place.
 */
export const SUGGESTION_HISTORY_THRESHOLD = 4;

/** How many distinct places the diary holds. */
export function distinctPlacesVisited(visits: Visit[]): number {
  return new Set(visits.map((v) => v.placeId)).size;
}

/**
 * Whether there is enough of a diary to suggest from.
 *
 * The gate lives here and is applied by the caller rather than inside
 * `suggestDay`, which stays pure: ranking with an empty diary is a
 * meaningful thing to ask for and the tests do ask for it.
 */
export function hasEnoughHistory(visits: Visit[]): boolean {
  return distinctPlacesVisited(visits) >= SUGGESTION_HISTORY_THRESHOLD;
}

function scorePlace(place: CuratedPlace, ctx: ScoreContext): Suggestion {
  const reasonDetail: Reason[] = [];
  let score = 0;

  // ——— Curation: our editorial judgment ———
  if (place.worthDetour) {
    score += 3;
    reasonDetail.push({ kind: 'detour', text: 'Worth a detour', fromDiary: false });
  }

  // ——— The diary: frequency and recency (PRD §3A.5) ———
  const stats = ctx.stats;
  if (stats) {
    const { goAgain, visitCount, daysSinceLastVisit } = stats;

    // Would-go-again is the ranking signal.
    score += goAgain.yes * 2.5;
    score -= goAgain.no * 4;

    // Frequency → preference. Sub-linear: eight visits is a favourite, not
    // eight times better than one.
    score += Math.log2(1 + visitCount) * 1.5;
    if (visitCount >= 3 && goAgain.no === 0) {
      reasonDetail.push({
        kind: 'regular',
        text: 'A regular of yours',
        fromDiary: true,
      });
    }

    // Recency → timely nudge. Loved but not recently seen scores highest;
    // somewhere visited last week is not news.
    //
    // The penalty tapers across the whole revisit window rather than
    // switching off after three days. Under the old cliff, a place stamped a
    // fortnight ago kept its would-go-again and frequency boosts with nothing
    // set against them and outranked everywhere unvisited, so a diary of four
    // recent places produced four suggestions to go straight back to them.
    if (goAgain.yes > 0) {
      if (daysSinceLastVisit >= REVISIT_SWEET_SPOT_DAYS) {
        score += 3;
        const months = Math.floor(daysSinceLastVisit / 30);
        reasonDetail.push({
          kind: 'overdue',
          text: `Not since ${months} month${months === 1 ? '' : 's'} ago`,
          fromDiary: true,
        });
      } else {
        score -= 5 * (1 - daysSinceLastVisit / REVISIT_SWEET_SPOT_DAYS);
      }
    }
  } else {
    // Unstamped places are how the diary grows, so they are not penalised —
    // an all-favourites day would make the wall stop growing.
    score += 1.5;
    reasonDetail.push({ kind: 'new', text: 'Somewhere new', fromDiary: false });
  }

  // ——— Affinities drawn from the diary ———
  // Both are specific by construction: they cannot exist without a record to
  // read them from, which is what makes them survive the prevalence rule
  // where "Somewhere new" cannot.
  //
  // Both are also about somewhere the user has not been. Telling someone that
  // a place they stamped a fortnight ago is near a place they liked is not a
  // reason to go back, it is a fact about the map.
  const { loved, topDistrict } = ctx.diary;
  const unstamped = !stats;
  if (
    unstamped &&
    loved.some((l) => haversineKm(l.location, place.location) <= NEAR_LOVED_KM)
  ) {
    reasonDetail.push({
      kind: 'nearLoved',
      text: 'Near somewhere you liked',
      fromDiary: true,
    });
  }
  if (unstamped && topDistrict && place.district === topDistrict) {
    reasonDetail.push({
      kind: 'district',
      text: 'A district you keep returning to',
      fromDiary: true,
    });
  }

  // ——— Practicality: keep the day walkable from the anchor ———
  score -= ctx.anchorKm * 0.4;

  return {
    place,
    score,
    reasons: reasonDetail.map((r) => r.text),
    reasonDetail,
  };
}

/** Read the shape of the diary once, rather than per candidate. */
function readDiary(
  places: CuratedPlace[],
  stats: Map<string, PlaceStats>
): DiaryContext {
  const loved = places.filter((p) => (stats.get(p.id)?.goAgain.yes ?? 0) > 0);

  const perDistrict = new Map<string, number>();
  for (const p of loved) {
    perDistrict.set(p.district, (perDistrict.get(p.district) ?? 0) + 1);
  }
  const [top] = [...perDistrict.entries()].sort(
    (a, b) => b[1] - a[1] || a[0].localeCompare(b[0])
  );

  return {
    loved,
    topDistrict: top && top[1] >= DISTRICT_AFFINITY_MIN ? top[0] : null,
  };
}

/**
 * Rank every published place for a day starting from `startPlace`.
 * Highest score first. Places beyond a sensible radius are dropped entirely.
 */
export function rankPlaces(
  places: CuratedPlace[],
  visits: Visit[],
  startPlace: StartPlace,
  now: number = Date.now()
): Suggestion[] {
  const stats = aggregateAll(visits, now);
  const diary = readDiary(places, stats);
  return places
    .map((place) => {
      const anchorKm = haversineKm(startPlace.location, place.location);
      return { place, anchorKm };
    })
    .filter((x) => x.anchorKm <= MAX_ANCHOR_KM)
    .map(({ place, anchorKm }) =>
      scorePlace(place, { stats: stats.get(place.id), anchorKm, diary })
    )
    .sort((a, b) => b.score - a.score || a.place.id.localeCompare(b.place.id));
}

/**
 * Drop reasons true of too much of the candidate set (PRD §3.3.0.3).
 *
 * This runs over the ranked set rather than inside `scorePlace`, because
 * prevalence is a property of the whole set and a single place cannot see it.
 * Keeping it out of the ranking also means the score is unaffected: this
 * changes what a card says, not what is offered.
 */
export function suppressCommonReasons(ranked: Suggestion[]): Suggestion[] {
  if (ranked.length === 0) return [];

  const seen = new Map<ReasonKind, number>();
  for (const s of ranked) {
    for (const r of s.reasonDetail) {
      seen.set(r.kind, (seen.get(r.kind) ?? 0) + 1);
    }
  }

  const keep = (r: Reason) =>
    r.fromDiary || (seen.get(r.kind) ?? 0) / ranked.length <= REASON_PREVALENCE_MAX;

  return ranked.map((s) => {
    const reasonDetail = s.reasonDetail.filter(keep);
    return { ...s, reasonDetail, reasons: reasonDetail.map((r) => r.text) };
  });
}

/**
 * Put the candidates that can be explained above the ones that cannot.
 *
 * The history gate exists because a suggestion nobody can justify should not
 * be made (§3.3.0.1). This is the same rule at a finer grain: once suppression
 * has run, a place with nothing true and specific left to say about it is a
 * worse suggestion than one that has, even where the raw score disagrees.
 * Without this, a diary of recent visits produces four cards with a blank
 * reason line — measured, not hypothesised.
 */
function explainedFirst(suggestions: Suggestion[]): Suggestion[] {
  return [...suggestions].sort(
    (a, b) =>
      (b.reasons.length > 0 ? 1 : 0) - (a.reasons.length > 0 ? 1 : 0) ||
      b.score - a.score ||
      a.place.id.localeCompare(b.place.id)
  );
}

/** The user's outing window, minutes since midnight. */
export interface DayWindow {
  dayStartMin: number;
  homeByMin: number;
}

/** Fewest stops worth calling a day out. A one-stop day is an errand. */
export const MIN_STOPS = 2;
/**
 * Most stops a suggested day may hold.
 *
 * Twelve is the theme spread's own ceiling: the dataset carries six distinct
 * primary themes and this function allows at most two per theme, so twelve is
 * where the two rules meet rather than one quietly overriding the other. From
 * a central anchor the achievable maximum is currently eleven, so the cap
 * binds on nothing today and starts working as the dataset gains themes.
 */
export const MAX_STOPS = 12;

/**
 * Door-to-door speed used only to size the day, km/h. Calibrated so the mean
 * straight-line leg across the top-ranked chain, about 1.3km, lands near the
 * 6.4 minutes the transport model produces for the same hop.
 *
 * ⚠️ TEMP FIXTURE, and deliberately crude. Real leg times belong to the
 * optimizer; the planner does not import it, because how many stops fit is a
 * different question from how to travel between them.
 */
const SIZING_SPEED_KMH = 12;

/** How much of `window` this place is open for, in minutes. */
function openMinutesInWindow(place: CuratedPlace, window: DayWindow): number {
  const { dayStartMin: start, homeByMin: end } = window;
  const span = Math.max(0, end - start);
  // No authored hours means an outdoor place with nothing to be shut.
  if (!place.openHours) return span;
  const from = Math.max(start, place.openHours.open);
  const to = Math.min(end, place.openHours.close);
  return Math.max(0, to - from);
}

/**
 * The window's usable minutes: each minute weighted by the share of
 * candidates open through it.
 *
 * A clock window is not an outing window. Widening the day to the full 24
 * hours adds hours in which almost nothing is open, and dividing raw clock
 * minutes by a dwell estimate would derive a day of stops that cannot be
 * visited. Weighting by availability means a longer window still buys more
 * stops, but at a falling rate, which is what the opening hours actually say.
 */
function usableMinutes(places: CuratedPlace[], window: DayWindow): number {
  if (places.length === 0) return 0;
  const total = places.reduce((sum, p) => sum + openMinutesInWindow(p, window), 0);
  return total / places.length;
}

/** Mean straight-line hop along a chain of places, km. */
function meanLegKm(places: CuratedPlace[]): number {
  if (places.length < 2) return 0;
  let km = 0;
  for (let i = 1; i < places.length; i++) {
    km += haversineKm(places[i - 1].location, places[i].location);
  }
  return km / (places.length - 1);
}

/**
 * How many stops fit the window (PRD §3.3.0.2). Derived from the time
 * available, the dwell estimates of the places in contention and the ground
 * between them — never fixed, and never asked for before the first output.
 */
export function deriveStopCount(
  ranked: Suggestion[],
  window: DayWindow
): number {
  if (ranked.length === 0) return 0;

  // Size against the places plausibly in the day rather than all 53: the
  // tail of the ranking is not what the user is being offered.
  const sample = ranked.slice(0, MAX_STOPS).map((s) => s.place);
  const minutes = usableMinutes(sample, window);
  const dwell =
    sample.reduce((sum, p) => sum + p.visitDurationMin, 0) / sample.length;
  const travel = (meanLegKm(sample) / SIZING_SPEED_KMH) * 60;

  const perStop = dwell + travel;
  if (perStop <= 0) return Math.min(ranked.length, MAX_STOPS);

  const derived = Math.floor(minutes / perStop);
  return Math.max(MIN_STOPS, Math.min(MAX_STOPS, derived));
}

/**
 * Pick a day's worth of places: the top-ranked ones, capped, and spread so a
 * day is not five bakeries. At most two places share a primary theme.
 *
 * `size` takes either an explicit count or the user's day window, in which
 * case the count is derived from it.
 */
export function suggestDay(
  places: CuratedPlace[],
  visits: Visit[],
  startPlace: StartPlace,
  size: number | DayWindow = 4,
  now: number = Date.now()
): Suggestion[] {
  const ranked = explainedFirst(
    suppressCommonReasons(rankPlaces(places, visits, startPlace, now))
  );
  const count =
    typeof size === 'number' ? size : deriveStopCount(ranked, size);
  const perTheme = new Map<string, number>();
  const chosen: Suggestion[] = [];

  for (const s of ranked) {
    if (chosen.length >= count) break;
    const primary = s.place.themes[0];
    const used = perTheme.get(primary) ?? 0;
    if (used >= 2) continue;
    perTheme.set(primary, used + 1);
    chosen.push(s);
  }
  return chosen;
}
