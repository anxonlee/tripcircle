import {
  aggregateAll,
  aggregateVisits,
  buildWallCards,
  newVisitId,
  visitTimeline,
  type Visit,
} from '../diary';
import { hkPlaces } from '../../services/mock/hkPlaces';

const DAY = 86_400_000;
const NOW = Date.UTC(2026, 6, 27, 12, 0, 0);

function visit(
  placeId: string,
  daysAgo: number,
  overrides: Partial<Visit> = {}
): Visit {
  return {
    id: `v-${placeId}-${daysAgo}`,
    placeId,
    timestamp: NOW - daysAgo * DAY,
    wouldGoAgain: 'yes',
    ...overrides,
  };
}

describe('visit aggregation', () => {
  it('returns null for a place with no visits', () => {
    expect(aggregateVisits('mido-cafe', [], NOW)).toBeNull();
  });

  it('counts visits and derives recency from the most recent one', () => {
    const visits = [
      visit('mido-cafe', 30),
      visit('mido-cafe', 3),
      visit('mido-cafe', 12),
    ];
    const stats = aggregateVisits('mido-cafe', visits, NOW)!;
    expect(stats.visitCount).toBe(3);
    expect(stats.lastVisitedAt).toBe(NOW - 3 * DAY);
    expect(stats.daysSinceLastVisit).toBe(3);
  });

  it('ignores visits belonging to other places', () => {
    const visits = [visit('mido-cafe', 1), visit('kam-wah-cafe', 1)];
    expect(aggregateVisits('mido-cafe', visits, NOW)!.visitCount).toBe(1);
  });

  it('tallies would-go-again per answer', () => {
    const visits = [
      visit('man-mo-temple', 5, { wouldGoAgain: 'yes' }),
      visit('man-mo-temple', 4, { wouldGoAgain: 'no' }),
      visit('man-mo-temple', 3, { wouldGoAgain: 'yes' }),
      visit('man-mo-temple', 2, { wouldGoAgain: 'maybe' }),
    ];
    const stats = aggregateVisits('man-mo-temple', visits, NOW)!;
    expect(stats.goAgain).toEqual({ yes: 2, maybe: 1, no: 1 });
  });

  it('averages only the visits that carried a rating', () => {
    const visits = [
      visit('sfmoma', 5, { rating: 5 }),
      visit('sfmoma', 4), // no rating — must not count as zero
      visit('sfmoma', 3, { rating: 3 }),
    ];
    const stats = aggregateVisits('sfmoma', visits, NOW)!;
    expect(stats.avgRating).toBe(4);
  });

  it('reports null average when no visit was rated', () => {
    expect(aggregateVisits('sfmoma', [visit('sfmoma', 1)], NOW)!.avgRating).toBeNull();
  });

  it('counts photos across visits', () => {
    const visits = [
      visit('ferry-building', 2, { photoUri: 'file:///a.jpg' }),
      visit('ferry-building', 1),
    ];
    expect(aggregateVisits('ferry-building', visits, NOW)!.photoCount).toBe(1);
  });
});

describe('per-visit notes (the Place/Visit split)', () => {
  it('keeps a separate note for every visit to the same place', () => {
    const visits = [
      visit('kam-wah-cafe', 10, { note: 'too crowded' }),
      visit('kam-wah-cafe', 2, { note: 'got the super burrito' }),
    ];
    const timeline = visitTimeline('kam-wah-cafe', visits);
    expect(timeline.map((v) => v.note)).toEqual([
      'got the super burrito',
      'too crowded',
    ]);
  });

  it('orders a timeline newest first', () => {
    const visits = [
      visit('kam-wah-cafe', 1),
      visit('kam-wah-cafe', 20),
      visit('kam-wah-cafe', 7),
    ];
    const days = visitTimeline('kam-wah-cafe', visits).map(
      (v) => Math.round((NOW - v.timestamp) / DAY)
    );
    expect(days).toEqual([1, 7, 20]);
  });
});

describe('aggregateAll', () => {
  it('keys stats by place and covers every stamped place', () => {
    const visits = [
      visit('mido-cafe', 1),
      visit('mido-cafe', 9),
      visit('man-mo-temple', 4),
    ];
    const all = aggregateAll(visits, NOW);
    expect([...all.keys()].sort()).toEqual(['man-mo-temple', 'mido-cafe']);
    expect(all.get('mido-cafe')!.visitCount).toBe(2);
  });

  it('is empty for an empty diary (the day-one state)', () => {
    expect(aggregateAll([], NOW).size).toBe(0);
  });
});

describe('wall cards', () => {
  it('builds one card per stamped place, newest first', () => {
    const visits = [
      visit('man-mo-temple', 8),
      visit('mido-cafe', 2),
      visit('kam-wah-cafe', 30),
    ];
    const cards = buildWallCards(hkPlaces, visits, NOW);
    expect(cards.map((c) => c.place.id)).toEqual([
      'mido-cafe',
      'man-mo-temple',
      'kam-wah-cafe',
    ]);
  });

  it('shows the most recent visit on the card', () => {
    const visits = [
      visit('mido-cafe', 20, { note: 'old note' }),
      visit('mido-cafe', 1, { note: 'fresh note' }),
    ];
    const [card] = buildWallCards(hkPlaces, visits, NOW);
    expect(card.latestVisit.note).toBe('fresh note');
    expect(card.stats.visitCount).toBe(2);
  });

  it('drops stamps whose place is no longer in the dataset', () => {
    const cards = buildWallCards(hkPlaces, [visit('deleted-place', 1)], NOW);
    expect(cards).toEqual([]);
  });

  it('renders nothing for an empty diary', () => {
    expect(buildWallCards(hkPlaces, [], NOW)).toEqual([]);
  });
});

describe('newVisitId', () => {
  it('does not collide across rapid successive stamps', () => {
    const ids = new Set(Array.from({ length: 500 }, () => newVisitId()));
    expect(ids.size).toBe(500);
  });
});
