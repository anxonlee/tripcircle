/**
 * Core domain types shared by services, the optimizer, and the UI.
 * Keep this file free of React Native / provider imports — it defines the
 * vocabulary everything else speaks (PRD §12: provider-swappable schema).
 *
 * PRD §12.2 models a place as THREE layers with different licensing and
 * caching rules. That split is load-bearing, not bookkeeping:
 *
 *   Foundation  (OSM/Geoapify) — cached, ODbL, factual skeleton
 *   Enrichment  (Google)       — LIVE ONLY, never written to storage
 *   Curation    (ours)         — cached, proprietary, what the planner uses
 *
 * Foundation and Curation are merged into `CuratedPlace` below, since we own
 * or may cache both. Enrichment is a separate type precisely so it cannot be
 * stored by accident — see the warning on `PlaceEnrichment`.
 *
 * Field names are camelCase to match the rest of the codebase; the PRD's
 * snake_case names are noted where they differ.
 */

/**
 * Fixed category set (PRD §6.1). The PRD's curation table calls this field
 * `themes` while §6.1 calls the palette "categories" — same concept, so the
 * type keeps the color-system name and the field keeps the PRD's.
 */
export type Category =
  | 'food'
  | 'historical'
  | 'shopping'
  | 'nature'
  | 'nightlife'
  | 'cafe';

export interface LatLng {
  latitude: number;
  longitude: number;
}

/**
 * Opening window in minutes since midnight (e.g. 9:00 = 540).
 * `close` may exceed 1440 for venues open past midnight (e.g. 26:00 = 1560).
 * `null` means always open (streets, parks with no gate).
 */
export interface OpenHours {
  open: number;
  close: number;
}

/** Our own price assessment, independent of Google's `priceLevel`. */
export type PriceBand = 'free' | '$' | '$$' | '$$$';

/** Planning hint — when this place is at its best. */
export type BestTime =
  | 'morning'
  | 'afternoon'
  | 'sunset'
  | 'evening'
  | 'weekday'
  | 'weekend';

/** Editorial workflow state. Only `published` places reach the planner. */
export type CurationStatus = 'published' | 'draft' | 'needs_review';

/**
 * HK launch districts. A closed union rather than a free string because the
 * memory wall auto-arranges cards by district (PRD §3A.3) and the planner
 * clusters by it — a typo would silently create a phantom district.
 */
export type District =
  | 'Central'
  | 'Tsim Sha Tsui'
  | 'Yau Ma Tei'
  | 'Mong Kok'
  | 'Causeway Bay'
  | 'Sham Shui Po';

/**
 * Foundation + Curation, merged. This is what the app lists, what the wall
 * renders, and the ONLY place data the optimizer may consume (PRD §12.2:
 * "never fed to the optimizer as stored values" applies to Google data).
 *
 * Deliberately absent: rating and reviewCount. Those are Google enrichment
 * and live on `PlaceEnrichment`, fetched live on detail open only.
 */
export interface CuratedPlace {
  /** Internal primary key everything links to (PRD `place_id`). */
  id: string;
  /** Links to Foundation (PRD `osm_id`). */
  osmId: string;
  /** Links to Enrichment. Null until the one-time linking search runs. */
  googlePlaceId: string | null;

  // ——— Foundation (OSM, cacheable under ODbL) ———
  name: string;
  location: LatLng;
  address: string;
  district: District;

  // ——— Curation (ours) ———
  /** Primary theme first — drives split-pin left half (PRD §6.1). */
  themes: Category[];
  /** Recommended time to spend, minutes. Fed directly to the optimizer. */
  visitDurationMin: number;
  priceBand: PriceBand;
  /**
   * Typical spend per visit, whole US dollars. Not a PRD curation field —
   * `priceBand` is the published signal — but the optimizer needs a number
   * to check against a budget cap, and this is our estimate, not Google's.
   * Integer by design: it is an estimate, and cents imply false precision.
   */
  avgCostUsd: number;
  /** Standout places the optimizer may route out of the way for. */
  worthDetour: boolean;
  openHours: OpenHours | null;
  bestTime?: BestTime;
  /** Insider note — entrance, what to order. */
  tips?: string;
  curator: string;
  curationStatus: CurationStatus;
}

/**
 * Google Places enrichment. ⚠️ LIVE ONLY — PRD §12.2.
 *
 * Rules this type exists to enforce:
 *  - NEVER written to AsyncStorage, a database, or any cache beyond the
 *    in-memory lifetime of an open place-detail screen.
 *  - Fetched ONLY on place-detail open. Never in list views, never
 *    speculatively, never for the optimizer.
 *  - Never exported, never included in shared posts or clones.
 *  - Only `googlePlaceId` may be persisted, and it lives on `CuratedPlace`.
 *
 * Nothing in this app should ever hold a `PlaceEnrichment` in a store.
 */
export interface PlaceEnrichment {
  googlePlaceId: string;
  rating: number | null;
  reviewCount: number | null;
  /** Google's own hours, which may disagree with our cached `openHours`. */
  hours: OpenHours | null;
  photoUrls: string[] | null;
  /** Google's 0–4 price level. Distinct from our `priceBand`. */
  priceLevel: number | null;
  /** Wall-clock ms when fetched, so stale in-memory copies are detectable. */
  fetchedAt: number;
}

/** Public landmarks offered as start places (PRD §3.1: landmark-first). */
export interface Landmark {
  id: string;
  name: string;
  kind: 'station' | 'plaza' | 'park' | 'landmark';
  location: LatLng;
}

/**
 * The user's chosen anchor. Location is ALWAYS coarse-snapped (~100m) before
 * it reaches this type — construct via `makeStartPlace` in lib/geo.ts.
 */
export interface StartPlace {
  id: string;
  name: string;
  kind: Landmark['kind'];
  location: LatLng;
}

/**
 * The modes the planner can put on a leg. Each prices differently — see
 * services/mock/transport.ts — and the optimizer's mode choice depends on
 * those structures differing, so they are named individually rather than
 * collapsed into one "transit".
 */
export type TransportMode = 'walk' | 'mtr' | 'bus' | 'tram' | 'ferry' | 'taxi';

/**
 * One travel option between two points, for one mode.
 *
 * `costUsd` is exact, NOT whole dollars. Hong Kong fares are small enough
 * that rounding a leg to the dollar destroys the fare structure — a HK$5
 * ferry and a HK$10.50 cross-harbour rail journey both become HK$7.80.
 * Round at display time (`formatHkd`), never here.
 */
export interface LegEstimate {
  mode: TransportMode;
  durationMin: number;
  costUsd: number;
  distanceKm: number;
}
