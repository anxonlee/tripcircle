import BottomSheet, { BottomSheetScrollView } from '@gorhom/bottom-sheet';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  useWindowDimensions,
  View,
} from 'react-native';
import MapView, { Marker, Polyline } from 'react-native-maps';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { CategoryPin, PIN_ANCHOR, PinSlot, StartPin } from '../components/CategoryPin';
import { transportIcon, transportLabel } from '../components/icons';
import { TimelineNode } from '../components/IconTile';
import type { CuratedPlace, TransportMode } from '../domain/types';
import { formatTime } from '../lib/geo';
import { formatDayTotalHkd, formatDuration, formatHkd } from '../lib/format';
import {
  optimizeDay,
  type DayPlan,
  type Goal,
  type LegOptionsFn,
} from '../lib/optimizer';
import type { RootStackParamList } from '../navigation';
import { placesService } from '../services/places';
import { routingService } from '../services/routing';
import { useTripStore, useUiStore } from '../store/useTripStore';
import { colors } from '../theme/colors';

type Props = NativeStackScreenProps<RootStackParamList, 'DayPlan'>;

/**
 * The four objectives, in the order they appear in the bar and the pager.
 * Ordered as a spectrum on money-versus-time, with Least Walking last
 * because it sits on a different axis entirely.
 *
 * "Least Walking" is a literal description of what the optimiser does: it
 * penalises walking distance. It is deliberately not called accessible,
 * step-free, or wheelchair-friendly. The model holds no accessibility data —
 * no lift locations, no step-free exits, no low-floor vehicle information —
 * so any of those labels would be a claim the software cannot support.
 */
const OBJECTIVES: { goal: Goal; label: string; icon: 'piggy-bank-outline' | 'scale-balance' | 'lightning-bolt' | 'seat-passenger' }[] = [
  { goal: 'economic', label: 'Economic', icon: 'piggy-bank-outline' },
  { goal: 'balanced', label: 'Balanced', icon: 'scale-balance' },
  { goal: 'fastest', label: 'Fastest', icon: 'lightning-bolt' },
  { goal: 'leastWalking', label: 'Least Walking', icon: 'seat-passenger' },
];

/**
 * Plan day — the optimizer's output made visible (ui-guide §1.4: never show
 * an optimized result without its numbers). Clay dashed loop on the map,
 * numbered pins in route order, summary cells, timeline with leg chips, and
 * a four-objective bar over a swipeable pager.
 *
 * All four plans are solved once when the selection changes and held in a
 * memo. Switching objective, by tap or by swipe, only reads that cache.
 */
export function PlanScreen({ navigation }: Props) {
  const insets = useSafeAreaInsets();
  const startPlace = useTripStore((s) => s.startPlace);
  const selectedIds = useTripStore((s) => s.selectedPlaceIds);
  const goal = useTripStore((s) => s.goal);
  const setGoal = useTripStore((s) => s.setGoal);
  const togglePlace = useTripStore((s) => s.togglePlace);
  const dayStartMin = useTripStore((s) => s.dayStartMin);
  const homeByMin = useTripStore((s) => s.homeByMin);
  const highlightedId = useUiStore((s) => s.highlightedPlaceId);
  const setHighlighted = useUiStore((s) => s.setHighlighted);
  const { width } = useWindowDimensions();

  const [selectedPlaces, setSelectedPlaces] = useState<CuratedPlace[]>([]);
  const [legOptionsFn, setLegOptionsFn] = useState<LegOptionsFn | null>(null);
  const mapRef = useRef<MapView>(null);
  const pagerRef = useRef<ScrollView>(null);
  const barRef = useRef<ScrollView>(null);
  /** Measured x/width per segment, so the bar can scroll one into view. */
  const segLayout = useRef<Record<string, { x: number; w: number }>>({});
  /** Live bar scroll offset and viewport width, for that visibility test. */
  const barScrollX = useRef(0);
  const barViewportW = useRef(0);

  useEffect(() => {
    placesService.listPlaces().then((all) => {
      const byId = new Map(all.map((p) => [p.id, p]));
      setSelectedPlaces(
        selectedIds.map((id) => byId.get(id)).filter((p): p is CuratedPlace => !!p)
      );
    });
    routingService.getLegOptionsFn().then((fn) => setLegOptionsFn(() => fn));
  }, [selectedIds]);

  /**
   * Every objective is solved here, once, and cached until the selection
   * changes. Four solves of a typical day cost single-digit milliseconds
   * together, so paying for all of them up front buys instant switching.
   */
  const plans = useMemo<Record<Goal, DayPlan> | null>(() => {
    if (!startPlace || !legOptionsFn || selectedPlaces.length === 0) return null;
    const base = {
      startPlace,
      places: selectedPlaces,
      dayStartMin,
      homeByMin,
      legOptions: legOptionsFn,
    };
    return {
      economic: optimizeDay({ ...base, goal: 'economic' }),
      balanced: optimizeDay({ ...base, goal: 'balanced' }),
      fastest: optimizeDay({ ...base, goal: 'fastest' }),
      leastWalking: optimizeDay({ ...base, goal: 'leastWalking' }),
    };
  }, [startPlace, selectedPlaces, legOptionsFn, dayStartMin, homeByMin]);

  const plan = plans?.[goal] ?? null;
  const goalIndex = OBJECTIVES.findIndex((o) => o.goal === goal);

  /** Tap on the bar: move the pager, which is the single source of truth. */
  const selectGoal = useCallback(
    (next: Goal) => {
      const i = OBJECTIVES.findIndex((o) => o.goal === next);
      pagerRef.current?.scrollTo({ x: i * width, animated: true });
      setGoal(next);
    },
    [width, setGoal]
  );

  /** Swipe: keep the bar in sync. Reads cache only, never re-solves. */
  const onPagerSettled = useCallback(
    (x: number) => {
      const i = Math.round(x / width);
      const next = OBJECTIVES[i]?.goal;
      if (next && next !== goal) setGoal(next);
    },
    [width, goal, setGoal]
  );

  const routeCoords = useMemo(() => {
    if (!plan || !startPlace) return [];
    return [
      startPlace.location,
      ...plan.stops.map((s) => s.place.location),
      startPlace.location,
    ];
  }, [plan, startPlace]);

  useEffect(() => {
    if (routeCoords.length > 1) {
      mapRef.current?.fitToCoordinates(routeCoords, {
        edgePadding: { top: insets.top + 40, left: 50, right: 50, bottom: 560 },
        animated: true,
      });
    }
  }, [routeCoords, insets.top]);

  /**
   * Four labels do not fit across a phone, so the selected one can sit off
   * the end of the bar and needs bringing into view.
   *
   * Scrolls the minimum distance to do that, and does nothing at all when the
   * segment is already fully visible. It is tempting to centre the selection
   * instead, but centring moves every other segment on every tap: tap one
   * objective, the bar slides, and the next tap lands on whichever segment
   * slid under the finger. Picking two objectives in a row then selects the
   * wrong one.
   *
   * Called from the goal effect and from each segment's onLayout, because on
   * first render the effect runs before the children have been measured and
   * there would be nothing to scroll to.
   */
  const revealActiveSeg = useCallback(
    (animated: boolean) => {
      const seg = segLayout.current[goal];
      const viewport = barViewportW.current;
      if (!seg || !viewport) return;
      const pad = 12;
      const left = barScrollX.current;
      const right = left + viewport;
      let target: number | null = null;
      if (seg.x - pad < left) target = Math.max(0, seg.x - pad);
      else if (seg.x + seg.w + pad > right) target = seg.x + seg.w + pad - viewport;
      if (target === null) return;
      barRef.current?.scrollTo({ x: target, animated });
    },
    [goal]
  );

  useEffect(() => {
    revealActiveSeg(true);
  }, [revealActiveSeg]);

  /**
   * Drop a stop from the day. Editing the selection is enough: the four plans
   * are a memo over it, so all of them re-solve and the map redraws.
   *
   * A day needs two stops to be a day, so the last two are not removable —
   * better to refuse than to drop the user into the empty state from a
   * control that looked like a tidy-up.
   */
  const removeStop = useCallback(
    (placeId: string, placeName: string) => {
      if (selectedIds.length <= 2) {
        Alert.alert(
          'Keep at least two places',
          'A day out needs somewhere to go and somewhere to go next. Add another place in Explore before removing this one.'
        );
        return;
      }
      Alert.alert(`Remove ${placeName}?`, 'The rest of the day re-plans around it.', [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: () => togglePlace(placeId),
        },
      ]);
    },
    [selectedIds.length, togglePlace]
  );

  const snapPoints = useMemo(() => ['35%', '60%', '90%'], []);

  /**
   * One objective's timeline. Rendered four times into the pager, so it takes
   * the plan rather than reading the selected one.
   */
  const renderTimeline = (p: DayPlan) => (
    <>
      <View style={styles.timelineRow}>
        <View style={styles.gutter}>
          <StartPin size={30} />
        </View>
        <Text style={styles.anchorText}>Leave {formatTime(p.dayStartMin)}</Text>
      </View>

      {p.stops.map((s) => (
        <View key={s.place.id}>
          <LegRow mode={s.leg.mode} durationMin={s.leg.durationMin} costUsd={s.leg.costUsd} />
          <Pressable
            onPress={() => {
              setHighlighted(s.place.id);
              mapRef.current?.animateToRegion(
                { ...s.place.location, latitudeDelta: 0.02, longitudeDelta: 0.02 },
                200
              );
            }}
            style={[
              styles.timelineRow,
              highlightedId === s.place.id && styles.stopHighlighted,
            ]}
          >
            <View style={styles.gutter}>
              <TimelineNode categories={s.place.themes} label={String(s.order)} />
            </View>
            <View style={styles.stopBody}>
              <Text style={styles.stopName} numberOfLines={1}>
                {s.place.name}
              </Text>
              <Text style={styles.stopCost}>
                {s.place.avgCostUsd > 0 ? `${formatHkd(s.place.avgCostUsd)} · ` : ''}
                {s.place.visitDurationMin} min visit
                {s.waitMin >= 15 ? ` · wait ${s.waitMin} min` : ''}
              </Text>
              {s.warnings.map((w, i) => (
                <View key={i} style={styles.warningRow}>
                  <MaterialCommunityIcons
                    name="alert-outline"
                    size={12}
                    color={colors.warning}
                  />
                  <Text style={styles.warningText}>{w}</Text>
                </View>
              ))}
            </View>
            <View style={styles.stopTail}>
              <Text style={styles.stopTime}>{formatTime(s.arriveMin)}</Text>
              <Pressable
                onPress={() => removeStop(s.place.id, s.place.name)}
                hitSlop={10}
                style={styles.removeStop}
              >
                <MaterialCommunityIcons
                  name="close"
                  size={14}
                  color={colors.textMuted}
                />
              </Pressable>
            </View>
          </Pressable>
        </View>
      ))}

      {p.returnLeg && (
        <>
          <LegRow
            mode={p.returnLeg.mode}
            durationMin={p.returnLeg.durationMin}
            costUsd={p.returnLeg.costUsd}
          />
          <View style={styles.timelineRow}>
            <View style={styles.gutter}>
              <StartPin size={30} />
            </View>
            <Text style={styles.anchorText}>Home by {formatTime(p.homeMin)}</Text>
          </View>
        </>
      )}

      {p.warnings.length > 0 && (
        <View style={styles.dayWarnings}>
          {p.warnings.map((w, i) => (
            <View key={i} style={styles.warningRow}>
              <MaterialCommunityIcons
                name="alert-outline"
                size={12}
                color={colors.warning}
              />
              <Text style={styles.warningText}>{w}</Text>
            </View>
          ))}
        </View>
      )}
    </>
  );

  if (!startPlace || selectedIds.length < 2) {
    return (
      <View style={styles.loading}>
        <MaterialCommunityIcons name="map-outline" size={22} color={colors.textMuted} />
        <Text style={styles.loadingText}>
          {startPlace
            ? 'Save at least two places in Explore to plan a day'
            : 'Set a start place first'}
        </Text>
        <Pressable style={styles.loadingBack} onPress={() => navigation.goBack()}>
          <Text style={styles.loadingBackText}>Back</Text>
        </Pressable>
      </View>
    );
  }

  if (!plan || !plans) {
    return (
      <View style={styles.loading}>
        <Text style={styles.loadingText}>Planning your day…</Text>
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <MapView
        ref={mapRef}
        style={StyleSheet.absoluteFill}
        onPress={() => setHighlighted(null)}
      >
        <Polyline
          coordinates={routeCoords}
          strokeColor="rgba(217,119,87,0.9)"
          strokeWidth={3.5}
          lineDashPattern={[2, 7]}
          lineCap="round"
        />
        <Marker
          coordinate={startPlace.location}
          anchor={PIN_ANCHOR}
          tracksViewChanges={false}
          zIndex={20}
        >
          <PinSlot>
            <StartPin />
          </PinSlot>
        </Marker>
        {plan.stops.map((s) => {
          const highlighted = highlightedId === s.place.id;
          return (
            <Marker
              key={`${s.place.id}-${s.order}-${highlighted ? 1 : 0}`}
              coordinate={s.place.location}
              anchor={PIN_ANCHOR}
              tracksViewChanges={false}
              zIndex={highlighted ? 30 : 1}
              onPress={() => setHighlighted(s.place.id)}
            >
              <PinSlot label={highlighted ? s.place.name : undefined}>
                <CategoryPin
                  categories={s.place.themes}
                  size={highlighted ? 35 : 28}
                  label={String(s.order)}
                />
              </PinSlot>
            </Marker>
          );
        })}
      </MapView>

      <Pressable
        style={[styles.backChip, { top: insets.top + 8 }]}
        onPress={() => navigation.goBack()}
      >
        <MaterialCommunityIcons name="chevron-left" size={18} color={colors.textPrimary} />
        <Text style={styles.backChipText}>Back</Text>
      </Pressable>

      {/* Publishing a plan is Phase 3 (PRD §14) — the share affordance lives
          in src/_legacy until the feed and moderation tooling ship. */}

      <BottomSheet
        index={1}
        snapPoints={snapPoints}
        backgroundStyle={styles.sheet}
        handleIndicatorStyle={styles.handle}
      >
        <View style={styles.sheetTop}>
          <View style={styles.sheetHeaderText}>
            <Text style={styles.sheetTitle}>Day plan</Text>
            <Text style={styles.sheetContext}>
              From {startPlace.name} · leave {formatTime(plan.dayStartMin)}
            </Text>
          </View>
          <ScrollView
            ref={barRef}
            horizontal
            showsHorizontalScrollIndicator={false}
            scrollEventThrottle={16}
            onScroll={(e) => {
              barScrollX.current = e.nativeEvent.contentOffset.x;
            }}
            onLayout={(e) => {
              barViewportW.current = e.nativeEvent.layout.width;
            }}
            contentContainerStyle={styles.objectiveBar}
          >
            {OBJECTIVES.map((o) => (
              <ObjectiveSeg
                key={o.goal}
                icon={o.icon}
                label={o.label}
                total={formatDayTotalHkd(plans[o.goal].totals.totalUsd)}
                duration={formatDuration(plans[o.goal].totals.travelMin)}
                active={goal === o.goal}
                onPress={() => selectGoal(o.goal)}
                onLayout={(x, w) => {
                  segLayout.current[o.goal] = { x, w };
                  if (o.goal === goal) revealActiveSeg(false);
                }}
              />
            ))}
          </ScrollView>
          <View style={styles.cellsRow}>
            <SummaryCell
              label="Day total"
              value={formatDayTotalHkd(plan.totals.totalUsd)}
            />
            <SummaryCell label="Travel" value={formatDuration(plan.totals.travelMin)} />
            <SummaryCell label="Home by" value={formatTime(plan.homeMin)} />
          </View>
        </View>

        <BottomSheetScrollView
          contentContainerStyle={{ paddingBottom: insets.bottom + 32 }}
        >
          {/* Horizontal pager: one page per objective, all rendered from the
              cache. Swiping settles on a page and reports back to the bar. */}
          <ScrollView
            ref={pagerRef}
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            contentOffset={{ x: goalIndex * width, y: 0 }}
            onMomentumScrollEnd={(e) =>
              onPagerSettled(e.nativeEvent.contentOffset.x)
            }
          >
            {OBJECTIVES.map((o) => (
              <View key={o.goal} style={{ width }}>
                {renderTimeline(plans[o.goal])}
              </View>
            ))}
          </ScrollView>
        </BottomSheetScrollView>
      </BottomSheet>
    </View>
  );
}

/**
 * One segment of the objective bar. Carries its own day total and travel
 * time so the four are comparable without switching between them
 * (ui-guide §5: never show an optimised result without its numbers).
 *
 * No clay here. The accent belongs to the screen's primary action, and a
 * selected segment is a state, not an action (ui-guide §1.3).
 */
function ObjectiveSeg({
  icon,
  label,
  total,
  duration,
  active,
  onPress,
  onLayout,
}: {
  icon: 'piggy-bank-outline' | 'scale-balance' | 'lightning-bolt' | 'seat-passenger';
  label: string;
  total: string;
  duration: string;
  active: boolean;
  onPress: () => void;
  onLayout: (x: number, w: number) => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      onLayout={(e) => onLayout(e.nativeEvent.layout.x, e.nativeEvent.layout.width)}
      style={[styles.objectiveSeg, active && styles.objectiveSegActive]}
    >
      <View style={styles.objectiveSegTop}>
        <MaterialCommunityIcons
          name={icon}
          size={13}
          color={active ? colors.textPrimary : colors.textSecondary}
        />
        <Text
          style={[styles.objectiveLabel, active && styles.objectiveLabelActive]}
          numberOfLines={1}
        >
          {label}
        </Text>
      </View>
      <Text style={[styles.objectiveMeta, active && styles.objectiveMetaActive]}>
        {total} · {duration}
      </Text>
    </Pressable>
  );
}

function SummaryCell({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.cell}>
      <Text style={styles.cellLabel}>{label}</Text>
      <Text style={styles.cellValue}>{value}</Text>
    </View>
  );
}

function LegRow({
  mode,
  durationMin,
  costUsd,
}: {
  mode: TransportMode;
  durationMin: number;
  costUsd: number;
}) {
  return (
    <View style={styles.legRow}>
      <View style={styles.gutter}>
        <View style={styles.spine} />
      </View>
      <View style={styles.legChip}>
        <MaterialCommunityIcons
          name={transportIcon[mode]}
          size={12}
          color={colors.textSecondary}
        />
        <Text style={styles.legText}>
          {transportLabel[mode]} {formatDuration(durationMin)}
          {costUsd > 0 ? ` · ${formatHkd(costUsd)}` : ''}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.surface },
  loading: {
    flex: 1,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingHorizontal: 40,
  },
  loadingText: { color: colors.textSecondary, fontSize: 14, textAlign: 'center' },
  loadingBack: {
    marginTop: 8,
    borderWidth: 1,
    borderColor: colors.borderStrong,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  loadingBackText: { fontSize: 13, fontWeight: '500', color: colors.textSecondary },
  backChip: {
    position: 'absolute',
    left: 16,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: 24,
    paddingLeft: 8,
    paddingRight: 13,
    height: 40,
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 1 },
  },
  backChipText: { fontSize: 13, fontWeight: '500', color: colors.textPrimary },
  shareChip: {
    position: 'absolute',
    right: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: colors.surface,
    borderRadius: 24,
    paddingLeft: 11,
    paddingRight: 13,
    height: 40,
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 1 },
  },
  sheet: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  handle: { backgroundColor: colors.borderStrong, width: 36, height: 4 },
  sheetTop: {
    paddingHorizontal: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    gap: 10,
  },
  sheetHeaderText: {},
  sheetTitle: { fontSize: 17, fontWeight: '500', color: colors.textPrimary },
  sheetContext: { fontSize: 12, color: colors.textMuted, marginTop: 1 },
  /**
   * Objective bar. Same segmented-control language as the old two-way
   * toggle (ui-guide §5): surfaceInput track, white active segment, subtle
   * shadow. Four labels do not fit a fixed row on a narrow phone, so the
   * track scrolls horizontally rather than truncating.
   */
  objectiveBar: {
    flexDirection: 'row',
    backgroundColor: colors.surfaceInput,
    borderRadius: 12,
    padding: 3,
    gap: 3,
  },
  objectiveSeg: {
    paddingHorizontal: 11,
    paddingVertical: 6,
    borderRadius: 9,
    gap: 1,
  },
  objectiveSegActive: {
    backgroundColor: colors.surface,
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 2,
    shadowOffset: { width: 0, height: 1 },
  },
  objectiveSegTop: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  objectiveLabel: { fontSize: 13, fontWeight: '500', color: colors.textSecondary },
  objectiveLabelActive: { color: colors.textPrimary },
  objectiveMeta: { fontSize: 11, color: colors.textMuted },
  objectiveMetaActive: { color: colors.textSecondary },
  cellsRow: { flexDirection: 'row', gap: 8 },
  cell: {
    flex: 1,
    backgroundColor: colors.surfaceAlt,
    borderRadius: 10,
    paddingVertical: 8,
    paddingHorizontal: 10,
  },
  cellLabel: { fontSize: 11, color: colors.textMuted },
  cellValue: { fontSize: 15, fontWeight: '500', color: colors.textPrimary, marginTop: 1 },
  timelineRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    paddingHorizontal: 16,
    paddingVertical: 8,
    gap: 12,
  },
  gutter: { width: 30, alignItems: 'center' },
  spine: { width: 2, height: 30, backgroundColor: colors.borderStrong },
  anchorText: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.textPrimary,
    marginTop: 5,
  },
  legRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    gap: 12,
  },
  legChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: colors.surfaceInput,
    borderRadius: 14,
    paddingHorizontal: 9,
    paddingVertical: 4,
  },
  legText: { fontSize: 11, color: colors.textSecondary },
  stopHighlighted: { backgroundColor: colors.surfaceAlt },
  stopBody: { flex: 1 },
  stopName: { fontSize: 14, fontWeight: '500', color: colors.textPrimary },
  stopCost: { fontSize: 11, color: colors.textMuted, marginTop: 2 },
  stopTime: { fontSize: 12, color: colors.textSecondary, marginTop: 2 },
  stopTail: { alignItems: 'flex-end', gap: 6 },
  removeStop: {
    width: 22,
    height: 22,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.surfaceInput,
  },
  warningRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 3,
  },
  warningText: { fontSize: 11, color: colors.warning, flexShrink: 1 },
  dayWarnings: {
    marginTop: 12,
    marginHorizontal: 16,
    gap: 2,
  },
});
