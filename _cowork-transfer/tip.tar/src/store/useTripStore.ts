import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import type { StartPlace } from '../domain/types';
import type { Goal } from '../lib/optimizer';

/**
 * Persisted planning state (local-only, AsyncStorage). The start place is
 * always coarse-snapped before it gets here (lib/geo.makeStartPlace) —
 * PRD §3.1 forbids persisting anything finer.
 */
interface TripState {
  startPlace: StartPlace | null;
  selectedPlaceIds: string[];
  goal: Goal;
  /**
   * Day window, minutes since midnight. Fixed defaults for now; a user-set
   * day window is Phase 2. There is deliberately no budget field: cost is
   * reported by the planner, never enforced.
   *
   * The default runs as late as the clock allows rather than to an invented
   * early finish. Opening hours are what should end a day, and the planner
   * weights the window by how much of the dataset is actually open through
   * it, so the extra evening hours buy stops only where there is somewhere
   * open to spend them.
   */
  dayStartMin: number;
  homeByMin: number;
  setStartPlace: (sp: StartPlace | null) => void;
  togglePlace: (id: string) => void;
  setSelection: (ids: string[]) => void;
  clearSelection: () => void;
  setGoal: (g: Goal) => void;
}

export const useTripStore = create<TripState>()(
  persist(
    (set) => ({
      startPlace: null,
      selectedPlaceIds: [],
      goal: 'balanced',
      dayStartMin: 9 * 60,
      homeByMin: 24 * 60,
      setStartPlace: (sp) => set({ startPlace: sp }),
      togglePlace: (id) =>
        set((s) => ({
          selectedPlaceIds: s.selectedPlaceIds.includes(id)
            ? s.selectedPlaceIds.filter((x) => x !== id)
            : [...s.selectedPlaceIds, id],
        })),
      setSelection: (ids) => set({ selectedPlaceIds: ids }),
      clearSelection: () => set({ selectedPlaceIds: [] }),
      setGoal: (g) => set({ goal: g }),
    }),
    {
      name: 'pirt-trip',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (s) => ({
        startPlace: s.startPlace,
        selectedPlaceIds: s.selectedPlaceIds,
        goal: s.goal,
        dayStartMin: s.dayStartMin,
        homeByMin: s.homeByMin,
      }),
    }
  )
);

/** Ephemeral UI state: pin ↔ list-item linking (PRD §6). Not persisted. */
interface UiState {
  highlightedPlaceId: string | null;
  setHighlighted: (id: string | null) => void;
}

export const useUiStore = create<UiState>()((set) => ({
  highlightedPlaceId: null,
  setHighlighted: (id) => set({ highlightedPlaceId: id }),
}));
