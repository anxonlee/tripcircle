import { MaterialCommunityIcons } from '@expo/vector-icons';
import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import type { CuratedPlace } from '../domain/types';
import { formatTime } from '../lib/geo';
import { categoryLabels, colors } from '../theme/colors';
import { IconTile } from './IconTile';

export const CARD_HEIGHT = 76;
export const CARD_GAP = 9;

/** Our own price band (PRD §12.2 curation), not Google's price level. */
const PRICE_LABEL: Record<CuratedPlace['priceBand'], string> = {
  free: 'Free',
  $: '$',
  $$: '$$',
  $$$: '$$$',
};

/**
 * Likely-open status incl. past-midnight closers (close > 24:00).
 *
 * Hedged on purpose. `openHours` is a single researched open/close pair with
 * no day-of-week, holidays, or seasonal changes, and the Google enrichment
 * that would make it authoritative (PRD §12.2) is not wired up yet — so this
 * is an estimate and says so. Telling someone a place is "Open now" and
 * sending them to a locked door costs more trust than the hedge costs.
 */
function openStatus(p: CuratedPlace): { open: boolean; text: string } {
  if (!p.openHours) return { open: true, text: '' };
  const now = new Date();
  const nowMin = now.getHours() * 60 + now.getMinutes();
  const { open, close } = p.openHours;
  const isOpen =
    (nowMin >= open && nowMin < close) ||
    (nowMin + 1440 >= open && nowMin + 1440 < close);
  return isOpen
    ? { open: true, text: `usually til ${formatTime(close)}` }
    : { open: false, text: `Usually opens ${formatTime(open)}` };
}

/**
 * Place card per ui-guide §5: tinted icon tile · name / meta / status ·
 * right distance + select control. Selected = positive border on the
 * selected well.
 *
 * The meta line shows CURATION only — worth-a-detour, themes, price band.
 * It deliberately shows no rating or review count: those are Google
 * enrichment, and PRD §12.2 forbids fetching them for list views. Our
 * editorial judgment is the signal here, which is the whole premise.
 */
export function PlaceCard({
  place,
  selected,
  highlighted = false,
  distanceKm,
  onPress,
  onToggle,
}: {
  place: CuratedPlace;
  selected: boolean;
  highlighted?: boolean;
  distanceKm: number | null;
  onPress: () => void;
  onToggle: () => void;
}) {
  const status = openStatus(place);
  return (
    <Pressable
      onPress={onPress}
      style={[
        styles.card,
        selected && styles.cardSelected,
        highlighted && !selected && styles.cardHighlighted,
      ]}
    >
      <IconTile categories={place.themes} />
      <View style={styles.cardBody}>
        <Text style={styles.cardName} numberOfLines={1}>
          {place.name}
        </Text>
        <Text style={styles.cardMeta} numberOfLines={1}>
          {place.worthDetour && (
            <Text style={styles.cardDetour}>★ Worth a detour · </Text>
          )}
          <Text>
            {place.themes
              .slice(0, 2)
              .map((c) => categoryLabels[c])
              .join(' · ')}
          </Text>
          <Text> · {PRICE_LABEL[place.priceBand]}</Text>
        </Text>
        <Text style={styles.cardStatus} numberOfLines={1}>
          {status.open ? (
            <>
              <Text style={styles.cardOpen}>Usually open</Text>
              {status.text ? (
                <Text style={styles.cardStatusMuted}> · {status.text}</Text>
              ) : null}
            </>
          ) : (
            <Text style={styles.cardStatusMuted}>{status.text}</Text>
          )}
        </Text>
      </View>
      <View style={styles.cardRight}>
        {distanceKm != null && (
          <Text style={styles.cardDistance}>{distanceKm.toFixed(1)} km</Text>
        )}
        <Pressable onPress={onToggle} hitSlop={10}>
          {selected ? (
            <View style={styles.toggleSelected}>
              <MaterialCommunityIcons name="check" size={16} color="#FFFFFF" />
            </View>
          ) : (
            <View style={styles.toggleEmpty}>
              <MaterialCommunityIcons name="plus" size={16} color={colors.textSecondary} />
            </View>
          )}
        </Pressable>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    height: CARD_HEIGHT,
    marginBottom: CARD_GAP,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 11,
    padding: 11,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  cardSelected: {
    borderColor: colors.positive,
    backgroundColor: colors.selectedWell,
  },
  cardHighlighted: { borderColor: colors.borderStrong, backgroundColor: colors.surfaceAlt },
  cardBody: { flex: 1 },
  cardName: { fontSize: 14, fontWeight: '500', color: colors.textPrimary },
  cardMeta: { fontSize: 12, color: colors.textSecondary, marginTop: 2 },
  cardDetour: { color: '#E8A22F', fontWeight: '500' },
  cardStatus: { fontSize: 11, marginTop: 2 },
  cardOpen: { color: colors.positive, fontSize: 11, fontWeight: '500' },
  cardStatusMuted: { color: colors.textMuted, fontSize: 11 },
  cardRight: {
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    alignSelf: 'stretch',
    paddingVertical: 2,
  },
  cardDistance: { fontSize: 12, color: colors.textMuted },
  toggleEmpty: {
    width: 26,
    height: 26,
    borderRadius: 13,
    borderWidth: 1,
    borderColor: colors.borderStrong,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  toggleSelected: {
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: colors.positive,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
