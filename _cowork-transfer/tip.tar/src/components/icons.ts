import type { MaterialCommunityIcons } from '@expo/vector-icons';
import type { Category, Landmark, TransportMode } from '../domain/types';

type IconName = keyof typeof MaterialCommunityIcons.glyphMap;

export const categoryIcon: Record<Category, IconName> = {
  food: 'silverware-fork-knife',
  historical: 'bank',
  shopping: 'shopping',
  nature: 'tree',
  nightlife: 'glass-cocktail',
  cafe: 'coffee',
};

export const transportIcon: Record<TransportMode, IconName> = {
  walk: 'walk',
  mtr: 'subway-variant',
  bus: 'bus',
  tram: 'tram',
  ferry: 'ferry',
  taxi: 'taxi',
};

export const transportLabel: Record<TransportMode, string> = {
  walk: 'Walk',
  mtr: 'MTR',
  bus: 'Bus',
  tram: 'Tram',
  ferry: 'Ferry',
  taxi: 'Taxi',
};

export const landmarkIcon: Record<Landmark['kind'], IconName> = {
  station: 'train',
  plaza: 'fountain',
  park: 'tree',
  landmark: 'map-marker',
};
