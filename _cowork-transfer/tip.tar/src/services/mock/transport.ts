import type { LatLng, LegEstimate, TransportMode } from '../../domain/types';
import { haversineKm } from '../../lib/geo';
import { HKD_PER_USD } from '../../lib/format';

/**
 * Mock speed + fare tables approximating travel within Hong Kong. Pure and
 * synchronous so the optimizer can consume it directly; MockRoutingService
 * wraps it in the async RoutingService interface.
 *
 * ⚠️ TEMP FIXTURE: approximate, replace with live provider data.
 * Every speed and fare below is a plausible demonstration value, not a
 * verified current figure. Fares are marked individually so none of them can
 * be mistaken for authoritative. What is meant to be correct here is the
 * SHAPE of each fare — stepped, flat, fixed, or metered — because that is
 * what decides which mode the optimizer picks. The numbers are placeholders;
 * the structures are the claim.
 *
 * Fare structure differs per mode, and the differences drive mode choice:
 *  - MTR   stepped by distance band. Not flat, not continuous.
 *  - Bus   flat per route, independent of distance travelled.
 *  - Tram  single flat fare regardless of distance. HK Island only.
 *  - Ferry fixed per crossing.
 *  - Taxi  flagfall covering the first 2 km, then metered per km.
 *  - Walk  free.
 *
 * Speed differs the same way. The MTR is grade-separated and unaffected by
 * traffic; buses and trams share the road and are much slower. That gap is
 * what makes medium-length legs interesting to the optimizer.
 *
 * Fares are authored in HKD and converted to USD once, unrounded. HK fares
 * are small — most urban journeys land between US$0.40 and US$3 — so rounding
 * a leg to whole USD would quantise every fare in the app to multiples of
 * HK$7.80 and collapse the bands this module exists to model. Rounding is the
 * display layer's job; `formatHkd` takes it to whole Hong Kong dollars at the
 * edge, and `formatDayTotalHkd` snaps day totals to the nearest HK$5.
 */

const hkd = (amount: number) => amount / HKD_PER_USD;

/**
 * MTR fares are stepped by station pair, not by continuous distance. Modelled
 * as a banded lookup over straight-line distance: within a band the fare does
 * not move at all, and it jumps at each boundary.
 *
 * TEMP FIXTURE: approximate, replace with live provider data.
 * Octopus adult single, urban lines. Roughly HK$5–25 across the network.
 */
const MTR_FARE_BANDS: { maxKm: number; hkd: number }[] = [
  { maxKm: 2, hkd: 5.5 },
  { maxKm: 4, hkd: 8.0 },
  { maxKm: 7, hkd: 11.5 },
  { maxKm: 12, hkd: 16.0 },
  { maxKm: Infinity, hkd: 23.0 },
];

function mtrFareHkd(km: number, crossing: boolean): number {
  const band = MTR_FARE_BANDS.find((b) => km <= b.maxKm) ?? MTR_FARE_BANDS.at(-1)!;
  // Cross-harbour journeys sit one step up the scale.
  // TEMP FIXTURE: approximate, replace with live provider data.
  return band.hkd + (crossing ? 5 : 0);
}

/**
 * Victoria Harbour separates Hong Kong Island from Kowloon. Straight-line
 * distance lies about these legs badly: Tsim Sha Tsui to Central is ~1.5 km
 * on a map and completely unwalkable — everything goes through a tunnel or
 * onto a ferry.
 *
 * The curated districts sit cleanly either side of 22.29 N (Island tops out
 * at 22.285 in Causeway Bay; Kowloon starts at 22.293 in Tsim Sha Tsui), so
 * a latitude test is enough to detect a crossing at this fixture's fidelity.
 *
 * TEMP FIXTURE: a real routing provider knows about the tunnels and the
 * ferry piers and needs none of this.
 */
const HARBOUR_LAT = 22.29;

const onIsland = (p: LatLng) => p.latitude < HARBOUR_LAT;

function crossesHarbour(from: LatLng, to: LatLng): boolean {
  return onIsland(from) !== onIsland(to);
}

/**
 * The tram runs only along the north shore of Hong Kong Island, so it is
 * offered only when both ends of a leg sit in that corridor. This is the
 * geographic restriction expressed rather than left as a TODO — a leg in
 * Kowloon must never be quoted a tram fare.
 *
 * TEMP FIXTURE: a coarse latitude/longitude box standing in for the real
 * route geometry, which a provider supplies as a line, not a rectangle.
 */
const TRAM_CORRIDOR = { minLat: 22.272, maxLat: 22.290, minLon: 114.13, maxLon: 114.21 };

function inTramCorridor(p: LatLng): boolean {
  return (
    onIsland(p) &&
    p.latitude >= TRAM_CORRIDOR.minLat &&
    p.latitude <= TRAM_CORRIDOR.maxLat &&
    p.longitude >= TRAM_CORRIDOR.minLon &&
    p.longitude <= TRAM_CORRIDOR.maxLon
  );
}

/**
 * The ferry is not a general cross-harbour mode: it runs pier to pier, so it
 * is only an option when both ends of a leg are close enough to walk to one.
 * Without this the planner will happily sail you to Mong Kok, which is a
 * kilometre inland.
 *
 * TEMP FIXTURE: approximate, replace with live provider data. Real pier
 * locations and the routes between them come from the operator.
 */
const FERRY_PIERS: LatLng[] = [
  { latitude: 22.2874, longitude: 114.1614 }, // Central
  { latitude: 22.2936, longitude: 114.1687 }, // Tsim Sha Tsui
  { latitude: 22.2828, longitude: 114.1729 }, // Wan Chai
];

/** How far someone will walk to a pier before the ferry stops being worth it. */
const FERRY_CATCHMENT_KM = 1.0;

const nearAPier = (p: LatLng) =>
  FERRY_PIERS.some((pier) => haversineKm(p, pier) <= FERRY_CATCHMENT_KM);

interface ModeSpec {
  /** Door-to-door effective speed over straight-line distance, km/h. */
  speedKmH: number;
  /** Waiting / hailing / station or pier access, minutes. */
  overheadMin: number;
  /** Extra minutes when the leg crosses the harbour. */
  crossHarbourMin: number;
  /** Fare in HKD for this leg. Shape differs per mode — that is the point. */
  fareHkd: (km: number, crossing: boolean) => number;
}

/** TEMP FIXTURE: approximate, replace with live provider data. */
const MODE_TABLE: Record<TransportMode, ModeSpec> = {
  walk: {
    // Dense, crowded pavements and footbridge detours: quicker than a
    // hill-adjusted figure, slower than open-road walking.
    speedKmH: 4.6,
    overheadMin: 0,
    crossHarbourMin: 0,
    fareHkd: () => 0,
  },
  mtr: {
    // Grade-separated. Does not sit in traffic, which is the whole point.
    speedKmH: 24,
    // Headways are 2–4 min, so this is mostly reaching the station and
    // getting down to a deep platform and back up at the far end. Large
    // enough that the MTR loses to walking on short hops, which is what
    // actually happens.
    overheadMin: 10,
    crossHarbourMin: 6,
    fareHkd: mtrFareHkd,
  },
  bus: {
    // Shares the road, stops frequently.
    speedKmH: 12,
    overheadMin: 8,
    crossHarbourMin: 9,
    // Flat per route — boarding fare does not depend on how far you ride.
    // TEMP FIXTURE: approximate, replace with live provider data.
    fareHkd: (_km, crossing) => (crossing ? 12.0 : 6.8),
  },
  tram: {
    // Slowest thing on rails in the city, and that is its charm.
    speedKmH: 9,
    // Street-level boarding, very frequent.
    overheadMin: 6,
    // Never crosses; see legOptions.
    crossHarbourMin: 0,
    // Single flat fare regardless of distance.
    // TEMP FIXTURE: approximate, replace with live provider data.
    fareHkd: () => 3.0,
  },
  ferry: {
    speedKmH: 14,
    // Pier access plus the sailing interval.
    overheadMin: 9,
    crossHarbourMin: 0,
    // Fixed per crossing.
    // TEMP FIXTURE: approximate, replace with live provider data.
    fareHkd: () => 5.0,
  },
  taxi: {
    // Urban traffic on Nathan Rd and through Central is slow.
    speedKmH: 18,
    // Plentiful on any main road — this is walking to somewhere you can be
    // picked up, not waiting for a booking.
    overheadMin: 3,
    // Tunnel queues are the single worst delay in the city.
    crossHarbourMin: 8,
    // Urban (red) taxi: flagfall covers the first 2 km, then metered. The
    // high fixed floor is what makes the optimizer's "refuse a taxi saving
    // under four minutes" rule bite.
    // TEMP FIXTURE: approximate, replace with live provider data.
    fareHkd: (km, crossing) =>
      29.0 + Math.max(0, km - 2) * 10.5 + (crossing ? 30.0 : 0),
  },
};

/**
 * Walking further than this is never offered. Hong Kong is walkable, but
 * heat and humidity for much of the year — and the climb in Central and
 * Mid-Levels — make a long walk a worse idea than the map suggests.
 */
const MAX_WALK_KM = 2.0;
/** Below this, rail and bus are pointless: overhead dominates. */
const MIN_TRANSIT_KM = 0.8;
/** The tram stops often enough to be worth boarding sooner than the MTR. */
const MIN_TRAM_KM = 0.5;

export function estimateLeg(
  from: LatLng,
  to: LatLng,
  mode: TransportMode
): LegEstimate {
  const km = haversineKm(from, to);
  const crossing = crossesHarbour(from, to);
  const t = MODE_TABLE[mode];
  return {
    mode,
    distanceKm: km,
    durationMin: Math.ceil(
      (km / t.speedKmH) * 60 + t.overheadMin + (crossing ? t.crossHarbourMin : 0)
    ),
    // NOT rounded. Fares are authored in HKD and converted once. Rounding to
    // whole USD here quantised every fare in the app to multiples of HK$7.80,
    // which overstated a HK$5 ferry as HK$8 and understated a HK$10.50
    // cross-harbour rail journey as the same HK$8. Display rounds to whole
    // HKD at the edge — see formatHkd — so the exact value travels.
    costUsd: hkd(t.fareHkd(km, crossing)),
  };
}

/**
 * All sensible mode options for a leg, cheapest-first. Always returns at
 * least one option (taxi covers any distance).
 *
 * Availability, not just price, is what keeps plans honest: no walking
 * across the harbour however short the straight line looks, no tram off the
 * Island, and no ferry unless both ends are within walking distance of a
 * pier on opposite sides of the water.
 */
export function legOptions(from: LatLng, to: LatLng): LegEstimate[] {
  const km = haversineKm(from, to);
  const crossing = crossesHarbour(from, to);
  const add = (mode: TransportMode) => estimateLeg(from, to, mode);
  const options: LegEstimate[] = [];

  if (km <= MAX_WALK_KM && !crossing) options.push(add('walk'));
  if (km >= MIN_TRANSIT_KM || crossing) {
    options.push(add('mtr'));
    options.push(add('bus'));
  }
  if (km >= MIN_TRAM_KM && inTramCorridor(from) && inTramCorridor(to)) {
    options.push(add('tram'));
  }
  if (crossing && nearAPier(from) && nearAPier(to)) options.push(add('ferry'));
  options.push(add('taxi'));

  return options.sort((a, b) => a.costUsd - b.costUsd);
}
