import type { Landmark } from '../../domain/types';

/**
 * Public landmarks offered as start places (PRD §3.1 landmark-first:
 * stations, plazas, and park entrances — never home addresses).
 *
 * Chosen so that every district in the HK dataset has at least two plausible
 * anchors within a short walk, and so that no suggestion sits close enough to
 * a single residence to be identifying. Coordinates are coarse-snapped by
 * `makeStartPlace` before anything is persisted.
 *
 * TEMP FIXTURE: approximate coords, replace with provider data.
 * Every coordinate below was hand-placed from district knowledge, not
 * geocoded. They are block-accurate — enough to anchor a demo route and frame
 * the map — but they are NOT provider data, and nothing needing real precision
 * should trust them. The whole list is replaced by the first real landmark
 * pull.
 */
export const hkLandmarks: Landmark[] = [
  // ——————————————————— Central ———————————————————
  { id: 'lm-central-station', name: 'Central Station', kind: 'station', location: { latitude: 22.2818, longitude: 114.1578 } },
  { id: 'lm-admiralty-station', name: 'Admiralty Station', kind: 'station', location: { latitude: 22.2793, longitude: 114.1647 } },
  { id: 'lm-statue-square', name: 'Statue Square', kind: 'plaza', location: { latitude: 22.2818, longitude: 114.1602 } },
  { id: 'lm-star-ferry-central', name: 'Star Ferry Pier, Central', kind: 'landmark', location: { latitude: 22.2874, longitude: 114.1614 } },

  // ——————————————————— Tsim Sha Tsui ———————————————————
  { id: 'lm-tst-station', name: 'Tsim Sha Tsui Station', kind: 'station', location: { latitude: 22.2977, longitude: 114.1722 } },
  { id: 'lm-kowloon-park', name: 'Kowloon Park', kind: 'park', location: { latitude: 22.3003, longitude: 114.1700 } },
  { id: 'lm-star-ferry-tst', name: 'Star Ferry Pier, Tsim Sha Tsui', kind: 'landmark', location: { latitude: 22.2936, longitude: 114.1687 } },

  // ——————————————————— Mong Kok ———————————————————
  { id: 'lm-mong-kok-station', name: 'Mong Kok Station', kind: 'station', location: { latitude: 22.3193, longitude: 114.1694 } },
  { id: 'lm-langham-place', name: 'Langham Place', kind: 'landmark', location: { latitude: 22.3172, longitude: 114.1687 } },

  // ——————————————————— Causeway Bay ———————————————————
  { id: 'lm-causeway-bay-station', name: 'Causeway Bay Station', kind: 'station', location: { latitude: 22.2803, longitude: 114.1848 } },
  { id: 'lm-victoria-park', name: 'Victoria Park', kind: 'park', location: { latitude: 22.2823, longitude: 114.1889 } },
  { id: 'lm-times-square', name: 'Times Square', kind: 'landmark', location: { latitude: 22.2783, longitude: 114.1820 } },

  // ——————————————————— Sham Shui Po ———————————————————
  { id: 'lm-sham-shui-po-station', name: 'Sham Shui Po Station', kind: 'station', location: { latitude: 22.3306, longitude: 114.1622 } },
  { id: 'lm-dragon-centre', name: 'Dragon Centre', kind: 'landmark', location: { latitude: 22.3305, longitude: 114.1595 } },
];
