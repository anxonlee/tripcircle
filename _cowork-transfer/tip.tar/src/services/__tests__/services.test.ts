import { haversineKm, snapToCoarse, makeStartPlace, formatTime } from '../../lib/geo';
import { estimateLeg, legOptions } from '../mock/transport';
import { placesService } from '../places';
import { routingService } from '../routing';
import { pinColors } from '../../theme/colors';

const powell = { latitude: 37.7844, longitude: -122.4079 };
const deYoung = { latitude: 37.7715, longitude: -122.4686 };

describe('geo', () => {
  it('haversine matches a known ~5.5km distance', () => {
    const km = haversineKm(powell, deYoung);
    expect(km).toBeGreaterThan(4.5);
    expect(km).toBeLessThan(6.5);
  });

  it('snapToCoarse drops precision to ~100m (3 decimals)', () => {
    const snapped = snapToCoarse({ latitude: 37.784123456, longitude: -122.407954321 });
    expect(snapped).toEqual({ latitude: 37.784, longitude: -122.408 });
  });

  it('makeStartPlace never stores fine precision', () => {
    const sp = makeStartPlace({
      id: 'x',
      name: 'X',
      kind: 'station',
      location: { latitude: 37.78412345, longitude: -122.40795432 },
    });
    expect(String(sp.location.latitude).split('.')[1]?.length ?? 0).toBeLessThanOrEqual(3);
    expect(String(sp.location.longitude).split('.')[1]?.length ?? 0).toBeLessThanOrEqual(3);
  });

  it('formatTime renders minutes-since-midnight', () => {
    expect(formatTime(540)).toBe('9:00');
    expect(formatTime(1065)).toBe('17:45');
    expect(formatTime(1500)).toBe('1:00'); // past midnight wraps
  });
});

describe('mock transport tables', () => {
  it('walking is free and slower than taxi', () => {
    const walk = estimateLeg(powell, deYoung, 'walk');
    const taxi = estimateLeg(powell, deYoung, 'taxi');
    expect(walk.costUsd).toBe(0);
    expect(taxi.costUsd).toBeGreaterThan(0);
    expect(taxi.durationMin).toBeLessThan(walk.durationMin);
  });

  it('long legs exclude walking; short legs exclude rail', () => {
    const long = legOptions(powell, deYoung); // ~5.5km
    expect(long.map((o) => o.mode)).not.toContain('walk');
    const near = { latitude: 37.785, longitude: -122.408 }; // ~70m
    const short = legOptions(powell, near);
    expect(short.map((o) => o.mode)).not.toContain('mtr');
  });

  it('options are sorted cheapest-first and never empty', () => {
    const opts = legOptions(powell, deYoung);
    expect(opts.length).toBeGreaterThan(0);
    const costs = opts.map((o) => o.costUsd);
    expect(costs).toEqual([...costs].sort((a, b) => a - b));
  });
});

describe('places service (mock)', () => {
  it('serves ~40 curated places inside HK with valid curation fields', async () => {
    const all = await placesService.listPlaces();
    expect(all.length).toBeGreaterThanOrEqual(28);
    for (const p of all) {
      // Core HK Island + Kowloon, not the New Territories or the outlying
      // islands — the anchor model depends on it.
      expect(p.location.latitude).toBeGreaterThan(22.26);
      expect(p.location.latitude).toBeLessThan(22.35);
      expect(p.location.longitude).toBeGreaterThan(114.14);
      expect(p.location.longitude).toBeLessThan(114.20);
      expect(p.themes.length).toBeGreaterThanOrEqual(1);
      expect(p.visitDurationMin).toBeGreaterThan(0);
      expect(p.avgCostUsd).toBe(Math.round(p.avgCostUsd)); // whole dollars
      if (p.openHours) expect(p.openHours.close).toBeGreaterThan(p.openHours.open);
    }
  });

  it('never exposes Google enrichment on cached place data (PRD §12.2)', async () => {
    const all = await placesService.listPlaces();
    for (const p of all) {
      // Storing these would put us outside Google's terms; the only
      // persisted Google field allowed is googlePlaceId.
      expect(p).not.toHaveProperty('rating');
      expect(p).not.toHaveProperty('reviewCount');
      expect(p).not.toHaveProperty('priceLevel');
    }
  });

  it('nearbyPlaces resolves the closest curated place to a location fix', async () => {
    // Standing in Hong Kong Park.
    const near = await placesService.nearbyPlaces(
      { latitude: 22.2777, longitude: 114.1620 },
      0.5
    );
    expect(near[0].id).toBe('hong-kong-park');
  });

  it('searchLandmarks filters by name, empty query lists all', async () => {
    const all = await placesService.searchLandmarks('');
    expect(all.length).toBeGreaterThanOrEqual(10);
    const hits = await placesService.searchLandmarks('langham');
    expect(hits.map((l) => l.id)).toEqual(['lm-langham-place']);
  });
});

describe('routing service (mock)', () => {
  it('exposes a sync estimator for the optimizer', async () => {
    const fn = await routingService.getLegOptionsFn();
    expect(fn(powell, deYoung).length).toBeGreaterThan(0);
  });
});

describe('category colors (PRD §6.1)', () => {
  it('caps pin colors at two, primary first', () => {
    expect(pinColors(['historical', 'shopping', 'food'])).toEqual(['#E8A22F', '#2F7FE8']);
    expect(pinColors(['food'])).toEqual(['#E8542F']);
  });
});
