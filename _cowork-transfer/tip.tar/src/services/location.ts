import * as Location from 'expo-location';
import type { LatLng } from '../domain/types';

/**
 * Foreground-only location (PRD §3A.6, FD6).
 *
 * The single rule this module exists to enforce: location is read ONLY in
 * the foreground, at the moment the user taps to stamp. There is no
 * background permission, no watcher, no subscription, and nothing here
 * caches or persists a fix. A position is used to answer "which place am I
 * at right now" and then discarded.
 *
 * If you ever need `startLocationUpdatesAsync` or a background task, that is
 * a product decision to revisit with the PRD, not an implementation detail.
 */

export type FixResult =
  | { status: 'ok'; location: LatLng }
  | { status: 'denied' }
  | { status: 'unavailable'; reason: string };

export interface LocationService {
  /** Ask for a single foreground fix, prompting for permission if needed. */
  getFix(): Promise<FixResult>;
}

class ExpoLocationService implements LocationService {
  async getFix(): Promise<FixResult> {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return { status: 'denied' };

      // Balanced accuracy is plenty: we only need to pick the nearest
      // curated place, and it is faster and less power-hungry than Highest.
      const pos = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });
      return {
        status: 'ok',
        location: {
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
        },
      };
    } catch (e) {
      return {
        status: 'unavailable',
        reason: e instanceof Error ? e.message : 'Location unavailable',
      };
    }
  }
}

/** App-wide singleton. Swap the implementation here, nowhere else. */
export const locationService: LocationService = new ExpoLocationService();
