import type {
  CuratedPlace,
  Landmark,
  LatLng,
  PlaceEnrichment,
} from '../domain/types';
import { haversineKm } from '../lib/geo';
import { hkLandmarks } from './mock/landmarks';
import { hkPlaces } from './mock/hkPlaces';

/**
 * THE provider boundary for POI data (PRD §12: map/POI licensing).
 * Components and stores may only reach place data through this interface —
 * never import mock data (or a future SDK) directly. Swapping to
 * Geoapify/OSM + Google later means writing one new class implementing this.
 *
 * Methods are async even though the mock is instant, because every real
 * provider will be.
 *
 * The Foundation/Curation methods and the Enrichment method are deliberately
 * separate: everything except `getEnrichment` is cacheable and free to call
 * in list views, while `getEnrichment` is a live Google call that may only
 * fire on place-detail open (PRD §12.2).
 */
export interface PlacesService {
  /** Landmark suggestions for start-place setup. Empty query = popular list. */
  searchLandmarks(query: string): Promise<Landmark[]>;
  /** All curated places. Foundation + Curation only — safe for list views. */
  listPlaces(): Promise<CuratedPlace[]>;
  getPlace(id: string): Promise<CuratedPlace | undefined>;
  /** Name/address/district search — backs the stamp picker. */
  searchPlaces(query: string): Promise<CuratedPlace[]>;
  /**
   * Curated places nearest a point, closest first. Used to resolve
   * "where am I" at stamp time from a foreground location fix.
   */
  nearbyPlaces(to: LatLng, limitKm?: number): Promise<CuratedPlace[]>;
  /**
   * ⚠️ LIVE Google call — PRD §12.2. Call ONLY on place-detail open.
   * Never in a list, never speculatively, never for the optimizer. The
   * result must not be persisted; only `googlePlaceId` may be stored.
   */
  getEnrichment(placeId: string): Promise<PlaceEnrichment | null>;
}

/** Only published curation reaches the app. */
const published = hkPlaces.filter((p) => p.curationStatus === 'published');

class MockPlacesService implements PlacesService {
  async searchLandmarks(query: string): Promise<Landmark[]> {
    const q = query.trim().toLowerCase();
    if (!q) return hkLandmarks;
    return hkLandmarks.filter((lm) => lm.name.toLowerCase().includes(q));
  }

  async listPlaces(): Promise<CuratedPlace[]> {
    return published;
  }

  async getPlace(id: string): Promise<CuratedPlace | undefined> {
    return published.find((p) => p.id === id);
  }

  async searchPlaces(query: string): Promise<CuratedPlace[]> {
    const q = query.trim().toLowerCase();
    if (!q) return published;
    return published.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.address.toLowerCase().includes(q) ||
        p.district.toLowerCase().includes(q)
    );
  }

  async nearbyPlaces(to: LatLng, limitKm = 1.5): Promise<CuratedPlace[]> {
    return published
      .map((p) => ({ p, km: haversineKm(to, p.location) }))
      .filter((x) => x.km <= limitKm)
      .sort((a, b) => a.km - b.km)
      .map((x) => x.p);
  }

  /**
   * No Google integration yet, so this returns null rather than inventing
   * ratings. Returning fabricated enrichment would be worse than returning
   * nothing: the UI would look finished while testing nothing real, and the
   * numbers would be indistinguishable from live data in a screenshot.
   */
  async getEnrichment(_placeId: string): Promise<PlaceEnrichment | null> {
    return null;
  }
}

/** App-wide singleton. Swap the implementation here, nowhere else. */
export const placesService: PlacesService = new MockPlacesService();
