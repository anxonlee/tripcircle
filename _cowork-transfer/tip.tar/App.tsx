import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { ErrorBoundary } from './src/components/ErrorBoundary';
import { TabBar } from './src/components/TabBar';
import type { RootStackParamList, TabParamList } from './src/navigation';
import { DiaryScreen } from './src/screens/DiaryScreen';
import { EditVisitScreen } from './src/screens/EditVisitScreen';
import { MemoryWallScreen } from './src/screens/MemoryWallScreen';
import { PlacesScreen } from './src/screens/PlacesScreen';
import { PlanScreen } from './src/screens/PlanScreen';
import { PlanSuggestScreen } from './src/screens/PlanSuggestScreen';
import { PrivacyScreen } from './src/screens/PrivacyScreen';
import { SetupScreen } from './src/screens/SetupScreen';
import { StampScreen } from './src/screens/StampScreen';
import { SummaryScreen } from './src/screens/SummaryScreen';
import { useDiaryStore } from './src/store/useDiaryStore';
import { useTripStore } from './src/store/useTripStore';
import { colors } from './src/theme/colors';

const Stack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator<TabParamList>();

function Tabs() {
  return (
    <Tab.Navigator
      tabBar={(props) => <TabBar {...props} />}
      screenOptions={{ headerShown: false }}
    >
      <Tab.Screen name="Wall" component={MemoryWallScreen} />
      <Tab.Screen name="Explore" component={PlacesScreen} />
      <Tab.Screen name="Plan" component={PlanSuggestScreen} />
      <Tab.Screen name="Summary" component={SummaryScreen} />
    </Tab.Navigator>
  );
}

/**
 * Wait for AsyncStorage rehydration before deciding the initial screen.
 * Both stores must land: showing an empty memory wall to someone with a
 * diary would read as data loss, which is the worst possible first frame.
 */
function useHydrated(): boolean {
  const [hydrated, setHydrated] = useState(
    useTripStore.persist.hasHydrated() && useDiaryStore.persist.hasHydrated()
  );
  useEffect(() => {
    const check = () =>
      setHydrated(
        useTripStore.persist.hasHydrated() && useDiaryStore.persist.hasHydrated()
      );
    const unsubTrip = useTripStore.persist.onFinishHydration(check);
    const unsubDiary = useDiaryStore.persist.onFinishHydration(check);
    return () => {
      unsubTrip();
      unsubDiary();
    };
  }, []);
  return hydrated;
}

export default function App() {
  const hydrated = useHydrated();
  const hasStartPlace = useTripStore((s) => s.startPlace !== null);

  if (!hydrated) {
    return (
      <View style={styles.splash}>
        <Text style={styles.splashBrand}>PIRT</Text>
      </View>
    );
  }

  return (
    <GestureHandlerRootView style={styles.root}>
      <ErrorBoundary>
        <SafeAreaProvider>
        <StatusBar style="dark" />
        <NavigationContainer>
          <Stack.Navigator
            initialRouteName={hasStartPlace ? 'Tabs' : 'Setup'}
            screenOptions={{ headerShown: false }}
          >
            <Stack.Screen name="Tabs" component={Tabs} />
            <Stack.Screen name="Setup" component={SetupScreen} />
            <Stack.Screen name="DayPlan" component={PlanScreen} />
            <Stack.Screen name="Stamp" component={StampScreen} />
            <Stack.Screen name="Privacy" component={PrivacyScreen} />
            <Stack.Screen name="Diary" component={DiaryScreen} />
            <Stack.Screen name="EditVisit" component={EditVisitScreen} />
          </Stack.Navigator>
        </NavigationContainer>
        </SafeAreaProvider>
      </ErrorBoundary>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  splash: {
    flex: 1,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  splashBrand: { fontSize: 20, fontWeight: '500', color: colors.textPrimary },
});
